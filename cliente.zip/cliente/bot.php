
<?php

/*
*
** Por @httd1<t.me/httd1>
*
*/
include __DIR__.'/includes/includes.php';

$tlg = new TelegramTools (TOKEN_BOT);

$updates = $tlg->getUpdates ();

for ($i = 0; $i < $tlg->UpdateCount (); $i++):

	$bd_tlg = new bdTelegram ();
	$redis = rDis::con ();
	$api_sms = new SMSActivate (KEY_SMS);
	$processos = new ControleProcessos ();

	$tlg->serveUpdate ($i);

	if (MODO_DESENVOLVEDOR && !in_array ($tlg->UserID (), ADMS)){
		exit;
	}

	// controla quantidade de usuarios adicionados no grupo e distribui saldos
	check_member ();
	
	// limpa usuarios novos e saidos do grupo
	limpa_novos ();

	// verifica se ta em grupo/canais ou pv
	if (!__is ('private')){
		continue;
	}

	// anti flood
	anti_flood ();

	show_logs ($updates); // mostra os logs de uso do bot

	// adiciona o usuário no bd ou pega inf. dele
	$user = $bd_tlg->usuario ($tlg->UserID ());

	// separa comando de complemento se nescessario
	@list ($comando, $complemento) = ($tlg->isCommand ()) ?
	@explode (' ', $tlg->Text (), 2) : [$tlg->Text (), null];

	switch ($comando):

		case '/start':
		case 'oi':
			include 'comandos/start.php';
		break;

		// Comandos Menus
		
		case '/catalogof':
			include 'comandos/catalogof.php';
		break;
		
		case '/catalogos':
			include 'comandos/catalogos.php';
		break;
		
		case '/pagina2serie':
			include 'comandos/pagina2serie.php';
		break;

		case '/pagina3serie':
			include 'comandos/pagina3serie.php';
		break;

		case '/pagina4serie':
			include 'comandos/pagina4serie.php';
		break;

		case '/pagina5serie':
			include 'comandos/pagina5serie.php';
		break;

		case '/temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (1).php';
		break;
		case '/ep2temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (2).php';
		break;
		case '/ep3temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (3).php';
		break;
		case '/ep4temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (4).php';
		break;
		case '/ep5temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (5).php';
		break;
		case '/ep6temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (6).php';
		break;
		case '/ep7temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (7).php';
		break;
		case '/ep8temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (8).php';
		break;
		case '/ep9temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (9).php';
		break;
		case '/ep10temp1theundergroundrailroad':
			include 'comandos/SERIES/theundergroundrailroad/temp (1)/ep (10).php';
		break;

		case '/temp2theoa':
			include 'comandos/SERIES/theoa/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2theoa':
			include 'comandos/SERIES/theoa/temp (2)/ep (1).php';
		break;
		case '/ep2temp2theoa':
			include 'comandos/SERIES/theoa/temp (2)/ep (2).php';
		break;
		case '/ep3temp2theoa':
			include 'comandos/SERIES/theoa/temp (2)/ep (3).php';
		break;
		case '/ep4temp2theoa':
			include 'comandos/SERIES/theoa/temp (2)/ep (4).php';
		break;
		case '/ep5temp2theoa':
			include 'comandos/SERIES/theoa/temp (2)/ep (5).php';
		break;
		case '/ep6temp2theoa':
			include 'comandos/SERIES/theoa/temp (2)/ep (6).php';
		break;
		case '/ep7temp2theoa':
			include 'comandos/SERIES/theoa/temp (2)/ep (7).php';
		break;
		case '/ep8temp2theoa':
			include 'comandos/SERIES/theoa/temp (2)/ep (8).php';
		break;

		case '/temp1theoa':
			include 'comandos/SERIES/theoa/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1theoa':
			include 'comandos/SERIES/theoa/temp (1)/ep (1).php';
		break;
		case '/ep2temp1theoa':
			include 'comandos/SERIES/theoa/temp (1)/ep (2).php';
		break;
		case '/ep3temp1theoa':
			include 'comandos/SERIES/theoa/temp (1)/ep (3).php';
		break;
		case '/ep4temp1theoa':
			include 'comandos/SERIES/theoa/temp (1)/ep (4).php';
		break;
		case '/ep5temp1theoa':
			include 'comandos/SERIES/theoa/temp (1)/ep (5).php';
		break;
		case '/ep6temp1theoa':
			include 'comandos/SERIES/theoa/temp (1)/ep (6).php';
		break;
		case '/ep7temp1theoa':
			include 'comandos/SERIES/theoa/temp (1)/ep (7).php';
		break;
		case '/ep8temp1theoa':
			include 'comandos/SERIES/theoa/temp (1)/ep (8).php';
		break;

		case '/temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (1).php';
		break;
		case '/ep2temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (2).php';
		break;
		case '/ep3temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (3).php';
		break;
		case '/ep4temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (4).php';
		break;
		case '/ep5temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (5).php';
		break;
		case '/ep6temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (6).php';
		break;
		case '/ep7temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (7).php';
		break;
		case '/ep8temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (8).php';
		break;
		case '/ep9temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (9).php';
		break;
		case '/ep10temp1theloomingtower':
			include 'comandos/SERIES/theloomingtower/temp (1)/ep (10).php';
		break;

		case '/temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (1).php';
		break;
		case '/ep2temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (2).php';
		break;
		case '/ep3temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (3).php';
		break;
		case '/ep4temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (4).php';
		break;
		case '/ep5temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (5).php';
		break;
		case '/ep6temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (6).php';
		break;
		case '/ep7temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (7).php';
		break;
		case '/ep8temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (8).php';
		break;
		case '/ep9temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (9).php';
		break;
		case '/ep10temp1stationeleven':
			include 'comandos/SERIES/stationeleven/temp (1)/ep (10).php';
		break;

		case '/temp1starwarsahsoka':
			include 'comandos/SERIES/starwarsahsoka/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1starwarsahsoka':
			include 'comandos/SERIES/starwarsahsoka/temp (1)/ep (1).php';
		break;
		case '/ep2temp1starwarsahsoka':
			include 'comandos/SERIES/starwarsahsoka/temp (1)/ep (2).php';
		break;
		case '/ep3temp1starwarsahsoka':
			include 'comandos/SERIES/starwarsahsoka/temp (1)/ep (3).php';
		break;
		case '/ep4temp1starwarsahsoka':
			include 'comandos/SERIES/starwarsahsoka/temp (1)/ep (4).php';
		break;
		case '/ep5temp1starwarsahsoka':
			include 'comandos/SERIES/starwarsahsoka/temp (1)/ep (5).php';
		break;
		case '/ep6temp1starwarsahsoka':
			include 'comandos/SERIES/starwarsahsoka/temp (1)/ep (6).php';
		break;
		case '/ep7temp1starwarsahsoka':
			include 'comandos/SERIES/starwarsahsoka/temp (1)/ep (7).php';
		break;
		case '/ep8temp1starwarsahsoka':
			include 'comandos/SERIES/starwarsahsoka/temp (1)/ep (8).php';
		break;

		case '/temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (1).php';
		break;
		case '/ep2temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (2).php';
		break;
		case '/ep3temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (3).php';
		break;
		case '/ep4temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (4).php';
		break;
		case '/ep5temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (5).php';
		break;
		case '/ep6temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (6).php';
		break;
		case '/ep7temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (7).php';
		break;
		case '/ep8temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (8).php';
		break;
		case '/ep9temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (9).php';
		break;
		case '/ep10temp2startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (2)/ep (10).php';
		break;

		case '/temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (1).php';
		break;
		case '/ep2temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (2).php';
		break;
		case '/ep3temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (3).php';
		break;
		case '/ep4temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (4).php';
		break;
		case '/ep5temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (5).php';
		break;
		case '/ep6temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (6).php';
		break;
		case '/ep7temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (7).php';
		break;
		case '/ep8temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (8).php';
		break;
		case '/ep9temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (9).php';
		break;
		case '/ep10temp1startrekstrangenewworlds':
			include 'comandos/SERIES/startrekstrangenewworlds/temp (1)/ep (10).php';
		break;

		case '/temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/ep (1).php';
		break;
		case '/ep2temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/ep (2).php';
		break;
		case '/ep3temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/ep (3).php';
		break;
		case '/ep4temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/ep (4).php';
		break;
		case '/ep5temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/ep (5).php';
		break;
		case '/ep6temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/ep (6).php';
		break;
		case '/ep7temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/ep (7).php';
		break;
		case '/ep8temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/ep (8).php';
		break;
		case '/ep9temp1songofthebandits':
			include 'comandos/SERIES/songofthebandits/temp (1)/ep (9).php';
		break;

		case '/temp2roma':
			include 'comandos/SERIES/roma/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (1).php';
		break;
		case '/ep2temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (2).php';
		break;
		case '/ep3temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (3).php';
		break;
		case '/ep4temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (4).php';
		break;
		case '/ep5temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (5).php';
		break;
		case '/ep6temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (6).php';
		break;
		case '/ep7temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (7).php';
		break;
		case '/ep8temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (8).php';
		break;
		case '/ep9temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (9).php';
		break;
		case '/ep10temp2roma':
			include 'comandos/SERIES/roma/temp (2)/ep (10).php';
		break;

		case '/temp1roma':
			include 'comandos/SERIES/roma/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (1).php';
		break;
		case '/ep2temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (2).php';
		break;
		case '/ep3temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (3).php';
		break;
		case '/ep4temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (4).php';
		break;
		case '/ep5temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (5).php';
		break;
		case '/ep6temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (6).php';
		break;
		case '/ep7temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (7).php';
		break;
		case '/ep8temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (8).php';
		break;
		case '/ep9temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (9).php';
		break;
		case '/ep10temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (10).php';
		break;
		case '/ep11temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (11).php';
		break;
		case '/ep12temp1roma':
			include 'comandos/SERIES/roma/temp (1)/ep (12).php';
		break;

		        case '/temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (1).php';
		break;
		case '/ep2temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (2).php';
		break;
		case '/ep3temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (3).php';
		break;
		case '/ep4temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (4).php';
		break;
		case '/ep5temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (5).php';
		break;
		case '/ep6temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (6).php';
		break;
		case '/ep7temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (7).php';
		break;
		case '/ep8temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (8).php';
		break;
		case '/ep9temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (9).php';
		break;
		case '/ep10temp1philipkdickselectricdreams':
			include 'comandos/SERIES/philipkdickselectricdreams/temp (1)/ep (10).php';
		break;

		case '/temp3perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (3)/ep (1).php';
		break;
		case '/ep2temp3perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (3)/ep (2).php';
		break;
		case '/ep3temp3perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (3)/ep (3).php';
		break;
		case '/ep4temp3perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (3)/ep (4).php';
		break;
		case '/ep5temp3perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (3)/ep (5).php';
		break;
		case '/ep6temp3perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (3)/ep (6).php';
		break;
		case '/ep7temp3perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (3)/ep (7).php';
		break;
		case '/ep8temp3perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (3)/ep (8).php';
		break;

		case '/temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (1).php';
		break;
		case '/ep2temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (2).php';
		break;
		case '/ep3temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (3).php';
		break;
		case '/ep4temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (4).php';
		break;
		case '/ep5temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (5).php';
		break;
		case '/ep6temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (6).php';
		break;
		case '/ep7temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (7).php';
		break;
		case '/ep8temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (8).php';
		break;
		case '/ep9temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (9).php';
		break;
		case '/ep10temp2perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (2)/ep (10).php';
		break;

		case '/temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (1).php';
		break;
		case '/ep2temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (2).php';
		break;
		case '/ep3temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (3).php';
		break;
		case '/ep4temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (4).php';
		break;
		case '/ep5temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (5).php';
		break;
		case '/ep6temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (6).php';
		break;
		case '/ep7temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (7).php';
		break;
		case '/ep8temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (8).php';
		break;
		case '/ep9temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (9).php';
		break;
		case '/ep10temp1perdidosnoespaço':
			include 'comandos/SERIES/perdidosnoespaço/temp (1)/ep (10).php';
		break;

		case '/temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/ep (1).php';
		break;
		case '/ep2temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/ep (2).php';
		break;
		case '/ep3temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/ep (3).php';
		break;
		case '/ep4temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/ep (4).php';
		break;
		case '/ep5temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/ep (5).php';
		break;
		case '/ep6temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/ep (6).php';
		break;
		case '/ep7temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/ep (7).php';
		break;
		case '/ep8temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/ep (8).php';
		break;
		case '/ep9temp3pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (3)/ep (9).php';
		break;

		

		case '/temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (1).php';
		break;
		case '/ep2temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (2).php';
		break;
		case '/ep3temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (3).php';
		break;
		case '/ep4temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (4).php';
		break;
		case '/ep5temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (5).php';
		break;
		case '/ep6temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (6).php';
		break;
		case '/ep7temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (7).php';
		break;
		case '/ep8temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (8).php';
		break;
		case '/ep9temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (9).php';
		break;
		case '/ep10temp2pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (2)/ep (10).php';
		break;

		case '/temp1pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (1)/ep (1).php';
		break;
		case '/ep2temp1pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (1)/ep (2).php';
		break;
		case '/ep3temp1pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (1)/ep (3).php';
		break;
		case '/ep4temp1pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (1)/ep (4).php';
		break;
		case '/ep5temp1pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (1)/ep (5).php';
		break;
		case '/ep6temp1pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (1)/ep (6).php';
		break;
		case '/ep7temp1pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (1)/ep (7).php';
		break;
		case '/ep8temp1pennydreadful':
			include 'comandos/SERIES/pennydreadful/temp (1)/ep (8).php';
		break;

		case '/temp2patriot':
			include 'comandos/SERIES/patriot/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2patriot':
			include 'comandos/SERIES/patriot/temp (2)/ep (1).php';
		break;
		case '/ep2temp2patriot':
			include 'comandos/SERIES/patriot/temp (2)/ep (2).php';
		break;
		case '/ep3temp2patriot':
			include 'comandos/SERIES/patriot/temp (2)/ep (3).php';
		break;
		case '/ep4temp2patriot':
			include 'comandos/SERIES/patriot/temp (2)/ep (4).php';
		break;
		case '/ep5temp2patriot':
			include 'comandos/SERIES/patriot/temp (2)/ep (5).php';
		break;
		case '/ep6temp2patriot':
			include 'comandos/SERIES/patriot/temp (2)/ep (6).php';
		break;
		case '/ep7temp2patriot':
			include 'comandos/SERIES/patriot/temp (2)/ep (7).php';
		break;
		case '/ep8temp2patriot':
			include 'comandos/SERIES/patriot/temp (2)/ep (8).php';
		break;

		case '/temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (1).php';
		break;
		case '/ep2temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (2).php';
		break;
		case '/ep3temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (3).php';
		break;
		case '/ep4temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (4).php';
		break;
		case '/ep5temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (5).php';
		break;
		case '/ep6temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (6).php';
		break;
		case '/ep7temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (7).php';
		break;
		case '/ep8temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (8).php';
		break;
		case '/ep9temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (9).php';
		break;
		case '/ep10temp1patriot':
			include 'comandos/SERIES/patriot/temp (1)/ep (10).php';
		break;

		case '/temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/bannertemp4.php';
		break;
		case '/ep1temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (1).php';
		break;
		case '/ep2temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (2).php';
		break;
		case '/ep3temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (3).php';
		break;
		case '/ep4temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (4).php';
		break;
		case '/ep5temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (5).php';
		break;
		case '/ep6temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (6).php';
		break;
		case '/ep7temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (7).php';
		break;
		case '/ep8temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (8).php';
		break;
		case '/ep9temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (9).php';
		break;
		case '/ep10temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (10).php';
		break;
		case '/ep11temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (11).php';
		break;
		case '/ep12temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (12).php';
		break;
		case '/ep13temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (13).php';
		break;
		case '/ep14temp4ozark':
			include 'comandos/SERIES/ozark/temp (4)/ep (14).php';
		break;

		case '/temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (1).php';
		break;
		case '/ep2temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (2).php';
		break;
		case '/ep3temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (3).php';
		break;
		case '/ep4temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (4).php';
		break;
		case '/ep5temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (5).php';
		break;
		case '/ep6temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (6).php';
		break;
		case '/ep7temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (7).php';
		break;
		case '/ep8temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (8).php';
		break;
		case '/ep9temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (9).php';
		break;
		case '/ep10temp3ozark':
			include 'comandos/SERIES/ozark/temp (3)/ep (10).php';
		break;

		case '/temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (1).php';
		break;
		case '/ep2temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (2).php';
		break;
		case '/ep3temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (3).php';
		break;
		case '/ep4temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (4).php';
		break;
		case '/ep5temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (5).php';
		break;
		case '/ep6temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (6).php';
		break;
		case '/ep7temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (7).php';
		break;
		case '/ep8temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (8).php';
		break;
		case '/ep9temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (9).php';
		break;
		case '/ep10temp2ozark':
			include 'comandos/SERIES/ozark/temp (2)/ep (10).php';
		break;

		case '/temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (1).php';
		break;
		case '/ep2temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (2).php';
		break;
		case '/ep3temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (3).php';
		break;
		case '/ep4temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (4).php';
		break;
		case '/ep5temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (5).php';
		break;
		case '/ep6temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (6).php';
		break;
		case '/ep7temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (7).php';
		break;
		case '/ep8temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (8).php';
		break;
		case '/ep9temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (9).php';
		break;
		case '/ep10temp1ozark':
			include 'comandos/SERIES/ozark/temp (1)/ep (10).php';
		break;

		case '/temp1oouro':
			include 'comandos/SERIES/oouro/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1oouro':
			include 'comandos/SERIES/oouro/temp (1)/ep (1).php';
		break;
		case '/ep2temp1oouro':
			include 'comandos/SERIES/oouro/temp (1)/ep (2).php';
		break;
		case '/ep3temp1oouro':
			include 'comandos/SERIES/oouro/temp (1)/ep (3).php';
		break;
		case '/ep4temp1oouro':
			include 'comandos/SERIES/oouro/temp (1)/ep (4).php';
		break;
		case '/ep5temp1oouro':
			include 'comandos/SERIES/oouro/temp (1)/ep (5).php';
		break;
		case '/ep6temp1oouro':
			include 'comandos/SERIES/oouro/temp (1)/ep (6).php';
		break;

		case '/temp1onepiece':
			include 'comandos/SERIES/onepiece/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1onepiece':
			include 'comandos/SERIES/onepiece/temp (1)/ep (1).php';
		break;
		case '/ep2temp1onepiece':
			include 'comandos/SERIES/onepiece/temp (1)/ep (2).php';
		break;
		case '/ep3temp1onepiece':
			include 'comandos/SERIES/onepiece/temp (1)/ep (3).php';
		break;
		case '/ep4temp1onepiece':
			include 'comandos/SERIES/onepiece/temp (1)/ep (4).php';
		break;
		case '/ep5temp1onepiece':
			include 'comandos/SERIES/onepiece/temp (1)/ep (5).php';
		break;
		case '/ep6temp1onepiece':
			include 'comandos/SERIES/onepiece/temp (1)/ep (6).php';
		break;
		case '/ep7temp1onepiece':
			include 'comandos/SERIES/onepiece/temp (1)/ep (7).php';
		break;
		case '/ep8temp1onepiece':
			include 'comandos/SERIES/onepiece/temp (1)/ep (8).php';
		break;

		case '/temp1mildredpierce':
			include 'comandos/SERIES/mildredpierce/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1mildredpierce':
			include 'comandos/SERIES/mildredpierce/temp (1)/ep (1).php';
		break;
		case '/ep2temp1mildredpierce':
			include 'comandos/SERIES/mildredpierce/temp (1)/ep (2).php';
		break;
		case '/ep3temp1mildredpierce':
			include 'comandos/SERIES/mildredpierce/temp (1)/ep (3).php';
		break;
		case '/ep4temp1mildredpierce':
			include 'comandos/SERIES/mildredpierce/temp (1)/ep (4).php';
		break;
		case '/ep5temp1mildredpierce':
			include 'comandos/SERIES/mildredpierce/temp (1)/ep (5).php';
		break;

		case '/temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (1).php';
		break;
		case '/ep2temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (2).php';
		break;
		case '/ep3temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (3).php';
		break;
		case '/ep4temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (4).php';
		break;
		case '/ep5temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (5).php';
		break;
		case '/ep6temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (6).php';
		break;
		case '/ep7temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (7).php';
		break;
		case '/ep8temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (8).php';
		break;
		case '/ep9temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (9).php';
		break;
		case '/ep10temp2mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (2)/ep (10).php';
		break;

		case '/temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (1).php';
		break;
		case '/ep2temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (2).php';
		break;
		case '/ep3temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (3).php';
		break;
		case '/ep4temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (4).php';
		break;
		case '/ep5temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (5).php';
		break;
		case '/ep6temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (6).php';
		break;
		case '/ep7temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (7).php';
		break;
		case '/ep8temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (8).php';
		break;
		case '/ep9temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (9).php';
		break;
		case '/ep10temp1mayorofkingstown':
			include 'comandos/SERIES/mayorofkingstown/temp (1)/ep (10).php';
		break;
		

		case '/temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (1).php';
		break;
		case '/ep2temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (2).php';
		break;
		case '/ep3temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (3).php';
		break;
		case '/ep4temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (4).php';
		break;
		case '/ep5temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (5).php';
		break;
		case '/ep6temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (6).php';
		break;
		case '/ep7temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (7).php';
		break;
		case '/ep8temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (8).php';
		break;
		case '/ep9temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (9).php';
		break;
		case '/ep10temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (10).php';
		break;
		case '/ep11temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (11).php';
		break;
		case '/ep12temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (12).php';
		break;
		case '/ep13temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (13).php';
		break;
		case '/ep14temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (14).php';
		break;
		case '/ep15temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (15).php';
		break;
		case '/ep16temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (16).php';
		break;
		case '/ep17temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (17).php';
		break;
		case '/ep18temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (18).php';
		break;
		case '/ep19temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (19).php';
		break;
		case '/ep20temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (20).php';
		break;

		case '/temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/bannertemp4.php';
		break;
		case '/ep1temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (1).php';
		break;
		case '/ep2temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (2).php';
		break;
		case '/ep3temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (3).php';
		break;
		case '/ep4temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (4).php';
		break;
		case '/ep5temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (5).php';
		break;
		case '/ep6temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (6).php';
		break;
		case '/ep7temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (7).php';
		break;
		case '/ep8temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (8).php';
		break;
		case '/ep9temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (9).php';
		break;
		case '/ep10temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (10).php';
		break;
		case '/ep11temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (11).php';
		break;
		case '/ep12temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (12).php';
		break;
		case '/ep13temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (13).php';
		break;

		case '/temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/bannertemp5.php';
		break;
		case '/ep1temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (1).php';
		break;
		case '/ep2temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (2).php';
		break;
		case '/ep3temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (3).php';
		break;
		case '/ep4temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (4).php';
		break;
		case '/ep5temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (5).php';
		break;
		case '/ep6temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (6).php';
		break;
		case '/ep7temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (7).php';
		break;
		case '/ep8temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (8).php';
		break;
		case '/ep9temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (9).php';
		break;
		case '/ep10temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (10).php';
		break;
		case '/ep11temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (11).php';
		break;
		case '/ep12temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (12).php';
		break;
		case '/ep13temp5madmen':
			include 'comandos/SERIES/madmen/temp (5)/ep (13).php';
		break;

		case '/temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/bannertemp7.php';
		break;
		case '/ep1temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (1).php';
		break;
		case '/ep2temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (2).php';
		break;
		case '/ep3temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (3).php';
		break;
		case '/ep4temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (4).php';
		break;
		case '/ep5temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (5).php';
		break;
		case '/ep6temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (6).php';
		break;
		case '/ep7temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (7).php';
		break;
		case '/ep8temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (8).php';
		break;
		case '/ep9temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (9).php';
		break;
		case '/ep10temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (10).php';
		break;
		case '/ep11temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (11).php';
		break;
		case '/ep12temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (12).php';
		break;
		case '/ep13temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (13).php';
		break;
		case '/ep14temp7madmen':
			include 'comandos/SERIES/madmen/temp (7)/ep (14).php';
		break;

		case '/temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/bannertemp6.php';
		break;
		case '/ep1temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (1).php';
		break;
		case '/ep2temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (2).php';
		break;
		case '/ep3temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (3).php';
		break;
		case '/ep4temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (4).php';
		break;
		case '/ep5temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (5).php';
		break;
		case '/ep6temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (6).php';
		break;
		case '/ep7temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (7).php';
		break;
		case '/ep8temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (8).php';
		break;
		case '/ep9temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (9).php';
		break;
		case '/ep10temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (10).php';
		break;
		case '/ep11temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (11).php';
		break;
		case '/ep12temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (12).php';
		break;
		case '/ep13temp6madmen':
			include 'comandos/SERIES/madmen/temp (6)/ep (13).php';
		break;

		case '/temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (1).php';
		break;
		case '/ep2temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (2).php';
		break;
		case '/ep3temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (3).php';
		break;
		case '/ep4temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (4).php';
		break;
		case '/ep5temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (5).php';
		break;
		case '/ep6temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (6).php';
		break;
		case '/ep7temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (7).php';
		break;
		case '/ep8temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (8).php';
		break;
		case '/ep9temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (9).php';
		break;
		case '/ep10temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (10).php';
		break;
		case '/ep11temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (11).php';
		break;
		case '/ep12temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (12).php';
		break;
		case '/ep13temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (13).php';
		break;
		case '/ep14temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (14).php';
		break;
		case '/ep15temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (15).php';
		break;
		case '/ep16temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (16).php';
		break;
		case '/ep17temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (17).php';
		break;
		case '/ep18temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (18).php';
		break;
		case '/ep19temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (19).php';
		break;
		case '/ep20temp3madmen':
			include 'comandos/SERIES/madmen/temp (3)/ep (20).php';
		break;

		case '/temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/bannertemp4.php';
		break;
		case '/ep1temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (1).php';
		break;
		case '/ep2temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (2).php';
		break;
		case '/ep3temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (3).php';
		break;
		case '/ep4temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (4).php';
		break;
		case '/ep5temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (5).php';
		break;
		case '/ep6temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (6).php';
		break;
		case '/ep7temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (7).php';
		break;
		case '/ep8temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (8).php';
		break;
		case '/ep9temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (9).php';
		break;
		case '/ep10temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (10).php';
		break;
		case '/ep11temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (11).php';
		break;
		case '/ep12temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (12).php';
		break;
		case '/ep13temp4madmen':
			include 'comandos/SERIES/madmen/temp (4)/ep (13).php';
		break;

		case '/temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (1).php';
		break;
		case '/ep2temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (2).php';
		break;
		case '/ep3temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (3).php';
		break;
		case '/ep4temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (4).php';
		break;
		case '/ep5temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (5).php';
		break;
		case '/ep6temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (6).php';
		break;
		case '/ep7temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (7).php';
		break;
		case '/ep8temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (8).php';
		break;
		case '/ep9temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (9).php';
		break;
		case '/ep10temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (10).php';
		break;
		case '/ep11temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (11).php';
		break;
		case '/ep12temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (12).php';
		break;
		case '/ep13temp2madmen':
			include 'comandos/SERIES/madmen/temp (2)/ep (13).php';
		break;

		case '/temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (1).php';
		break;
		case '/ep2temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (2).php';
		break;
		case '/ep3temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (3).php';
		break;
		case '/ep4temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (4).php';
		break;
		case '/ep5temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (5).php';
		break;
		case '/ep6temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (6).php';
		break;
		case '/ep7temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (7).php';
		break;
		case '/ep8temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (8).php';
		break;
		case '/ep9temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (9).php';
		break;
		case '/ep10temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (10).php';
		break;
		case '/ep11temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (11).php';
		break;
		case '/ep12temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (12).php';
		break;
		case '/ep13temp1madmen':
			include 'comandos/SERIES/madmen/temp (1)/ep (13).php';
		break;

		case '/temp2lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (2)/ep (1).php';
		break;
		case '/ep2temp2lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (2)/ep (2).php';
		break;
		case '/ep3temp2lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (2)/ep (3).php';
		break;
		case '/ep4temp2lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (2)/ep (4).php';
		break;
		case '/ep5temp2lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (2)/ep (5).php';
		break;
		case '/ep6temp2lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (2)/ep (6).php';
		break;
		case '/ep7temp2lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (2)/ep (7).php';
		break;

		case '/temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (1).php';
		break;
		case '/ep2temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (2).php';
		break;
		case '/ep3temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (3).php';
		break;
		case '/ep4temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (4).php';
		break;
		case '/ep5temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (5).php';
		break;
		case '/ep6temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (6).php';
		break;
		case '/ep7temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (7).php';
		break;
		case '/ep8temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (8).php';
		break;
		case '/ep9temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (9).php';
		break;
		case '/ep10temp1lakershoradevencer':
			include 'comandos/SERIES/lakershoradevencer/temp (1)/ep (10).php';
		break;

		case '/temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (1).php';
		break;
		case '/ep2temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (2).php';
		break;
		case '/ep3temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (3).php';
		break;
		case '/ep4temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (4).php';
		break;
		case '/ep5temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (5).php';
		break;
		case '/ep6temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (6).php';
		break;
		case '/ep7temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (7).php';
		break;
		case '/ep8temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (8).php';
		break;
		case '/ep9temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (9).php';
		break;
		case '/ep10temp2invasao':
			include 'comandos/SERIES/invasao/temp (2)/ep (10).php';
		break;

		case '/temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (1).php';
		break;
		case '/ep2temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (2).php';
		break;
		case '/ep3temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (3).php';
		break;
		case '/ep4temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (4).php';
		break;
		case '/ep5temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (5).php';
		break;
		case '/ep6temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (6).php';
		break;
		case '/ep7temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (7).php';
		break;
		case '/ep8temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (8).php';
		break;
		case '/ep9temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (9).php';
		break;
		case '/ep10temp1invasao':
			include 'comandos/SERIES/invasao/temp (1)/ep (10).php';
		break;

		case '/temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (1).php';
		break;
		case '/ep2temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (2).php';
		break;
		case '/ep3temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (3).php';
		break;
		case '/ep4temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (4).php';
		break;
		case '/ep5temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (5).php';
		break;
		case '/ep6temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (6).php';
		break;
		case '/ep7temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (7).php';
		break;
		case '/ep8temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (8).php';
		break;
		case '/ep9temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (9).php';
		break;
		case '/ep10temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (10).php';
		break;
		case '/ep11temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (11).php';
		break;
		case '/ep12temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (12).php';
		break;
		case '/ep13temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (13).php';
		break;
		case '/ep14temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (14).php';
		break;
		case '/ep15temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (15).php';
		break;
		case '/ep16temp3intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (3)/ep (16).php';
		break;

		case '/temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (1).php';
		break;
		case '/ep2temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (2).php';
		break;
		case '/ep3temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (3).php';
		break;
		case '/ep4temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (4).php';
		break;
		case '/ep5temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (5).php';
		break;
		case '/ep6temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (6).php';
		break;
		case '/ep7temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (7).php';
		break;
		case '/ep8temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (8).php';
		break;
		case '/ep9temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (9).php';
		break;
		case '/ep10temp2intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (2)/ep (10).php';
		break;

		case '/temp1intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (1)/ep (1).php';
		break;
		case '/ep2temp1intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (1)/ep (2).php';
		break;
		case '/ep3temp1intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (1)/ep (3).php';
		break;
		case '/ep4temp1intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (1)/ep (4).php';
		break;
		case '/ep5temp1intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (1)/ep (5).php';
		break;
		case '/ep6temp1intothebadlands':
			include 'comandos/SERIES/intothebadlands/temp (1)/ep (6).php';
		break;

		case '/temp3hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (3)/ep (1).php';
		break;
		case '/ep2temp3hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (3)/ep (2).php';
		break;
		case '/ep3temp3hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (3)/ep (3).php';
		break;
		case '/ep4temp3hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (3)/ep (4).php';
		break;
		case '/ep5temp3hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (3)/ep (5).php';
		break;
		case '/ep6temp3hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (3)/ep (6).php';
		break;
		case '/ep7temp3hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (3)/ep (7).php';
		break;
		case '/ep8temp3hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (3)/ep (8).php';
		break;

		case '/temp2hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (2)/ep (1).php';
		break;
		case '/ep2temp2hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (2)/ep (2).php';
		break;
		case '/ep3temp2hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (2)/ep (3).php';
		break;
		case '/ep4temp2hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (2)/ep (4).php';
		break;
		case '/ep5temp2hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (2)/ep (5).php';
		break;
		case '/ep6temp2hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (2)/ep (6).php';
		break;
		case '/ep7temp2hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (2)/ep (7).php';
		break;

		case '/temp1hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (1)/ep (1).php';
		break;
		case '/ep2temp1hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (1)/ep (2).php';
		break;
		case '/ep3temp1hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (1)/ep (3).php';
		break;
		case '/ep4temp1hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (1)/ep (4).php';
		break;
		case '/ep5temp1hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (1)/ep (5).php';
		break;
		case '/ep6temp1hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (1)/ep (6).php';
		break;
		case '/ep7temp1hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (1)/ep (7).php';
		break;
		case '/ep8temp1hisdarkmaterials':
			include 'comandos/SERIES/hisdarkmaterials/temp (1)/ep (8).php';
		break;

		case '/temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (1).php';
		break;
		case '/ep2temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (2).php';
		break;
		case '/ep3temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (3).php';
		break;
		case '/ep4temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (4).php';
		break;
		case '/ep5temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (5).php';
		break;
		case '/ep6temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (6).php';
		break;
		case '/ep7temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (7).php';
		break;
		case '/ep8temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (8).php';
		break;
		case '/ep9temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (9).php';
		break;
		case '/ep10temp3glow3':
			include 'comandos/SERIES/glow3/temp (3)/ep (10).php';
		break;

		case '/temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (1).php';
		break;
		case '/ep2temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (2).php';
		break;
		case '/ep3temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (3).php';
		break;
		case '/ep4temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (4).php';
		break;
		case '/ep5temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (5).php';
		break;
		case '/ep6temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (6).php';
		break;
		case '/ep7temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (7).php';
		break;
		case '/ep8temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (8).php';
		break;
		case '/ep9temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (9).php';
		break;
		case '/ep10temp2glow3':
			include 'comandos/SERIES/glow3/temp (2)/ep (10).php';
		break;

		case '/temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (1).php';
		break;
		case '/ep2temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (2).php';
		break;
		case '/ep3temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (3).php';
		break;
		case '/ep4temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (4).php';
		break;
		case '/ep5temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (5).php';
		break;
		case '/ep6temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (6).php';
		break;
		case '/ep7temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (7).php';
		break;
		case '/ep8temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (8).php';
		break;
		case '/ep9temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (9).php';
		break;
		case '/ep10temp1glow3':
			include 'comandos/SERIES/glow3/temp (1)/ep (10).php';
		break;

		case '/temp1genv':
			include 'comandos/SERIES/genv/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1genv':
			include 'comandos/SERIES/genv/temp (1)/ep (1).php';
		break;
		case '/ep2temp1genv':
			include 'comandos/SERIES/genv/temp (1)/ep (2).php';
		break;
		case '/ep3temp1genv':
			include 'comandos/SERIES/genv/temp (1)/ep (3).php';
		break;
		case '/ep4temp1genv':
			include 'comandos/SERIES/genv/temp (1)/ep (4).php';
		break;
		case '/ep5temp1genv':
			include 'comandos/SERIES/genv/temp (1)/ep (5).php';
		break;
		case '/ep6temp1genv':
			include 'comandos/SERIES/genv/temp (1)/ep (6).php';
		break;

		case '/temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (1).php';
		break;
		case '/ep2temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (2).php';
		break;
		case '/ep3temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (3).php';
		break;
		case '/ep4temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (4).php';
		break;
		case '/ep5temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (5).php';
		break;
		case '/ep6temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (6).php';
		break;
		case '/ep7temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (7).php';
		break;
		case '/ep8temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (8).php';
		break;
		case '/ep9temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (9).php';
		break;
		case '/ep10temp3evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (3)/ep (10).php';
		break;

		case '/temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (1).php';
		break;
		case '/ep2temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (2).php';
		break;
		case '/ep3temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (3).php';
		break;
		case '/ep4temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (4).php';
		break;
		case '/ep5temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (5).php';
		break;
		case '/ep6temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (6).php';
		break;
		case '/ep7temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (7).php';
		break;
		case '/ep8temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (8).php';
		break;
		case '/ep9temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (9).php';
		break;
		case '/ep10temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (10).php';
		break;
		case '/ep11temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (11).php';
		break;
		case '/ep12temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (12).php';
		break;
		case '/ep13temp2evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (2)/ep (13).php';
		break;

		case '/temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (1).php';
		break;
		case '/ep2temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (2).php';
		break;
		case '/ep3temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (3).php';
		break;
		case '/ep4temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (4).php';
		break;
		case '/ep5temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (5).php';
		break;
		case '/ep6temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (6).php';
		break;
		case '/ep7temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (7).php';
		break;
		case '/ep8temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (8).php';
		break;
		case '/ep9temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (9).php';
		break;
		case '/ep10temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (10).php';
		break;
		case '/ep11temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (11).php';
		break;
		case '/ep12temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (12).php';
		break;
		case '/ep13temp1evilcontatossobrenaturais':
			include 'comandos/SERIES/evilcontatossobrenaturais/temp (1)/ep (13).php';
		break;

		case '/temp4doompatrol':
			include 'comandos/SERIES/doompatrol/temp (4)/bannertemp4.php';
		break;
		case '/ep1temp4doompatrol':
			include 'comandos/SERIES/doompatrol/temp (4)/ep (1).php';
		break;
		case '/ep2temp4doompatrol':
			include 'comandos/SERIES/doompatrol/temp (4)/ep (2).php';
		break;
		case '/ep3temp4doompatrol':
			include 'comandos/SERIES/doompatrol/temp (4)/ep (3).php';
		break;
		case '/ep4temp4doompatrol':
			include 'comandos/SERIES/doompatrol/temp (4)/ep (4).php';
		break;
		case '/ep5temp4doompatrol':
			include 'comandos/SERIES/doompatrol/temp (4)/ep (5).php';
		break;
		case '/ep6temp4doompatrol':
			include 'comandos/SERIES/doompatrol/temp (4)/ep (6).php';
		break;
		case '/ep7temp4doompatrol':
			include 'comandos/SERIES/doompatrol/temp (4)/ep (7).php';
		break;
		case '/ep8temp4doompatrol':
			include 'comandos/SERIES/doompatrol/temp (4)/ep (8).php';
		break;

		case '/temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (1).php';
		break;
		case '/ep2temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (2).php';
		break;
		case '/ep3temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (3).php';
		break;
		case '/ep4temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (4).php';
		break;
		case '/ep5temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (5).php';
		break;
		case '/ep6temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (6).php';
		break;
		case '/ep7temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (7).php';
		break;
		case '/ep8temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (8).php';
		break;
		case '/ep9temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (9).php';
		break;
		case '/ep10temp3doompatrol':
			include 'comandos/SERIES/doompatrol/temp (3)/ep (10).php';
		break;

		case '/temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/ep (1).php';
		break;
		case '/ep2temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/ep (2).php';
		break;
		case '/ep3temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/ep (3).php';
		break;
		case '/ep4temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/ep (4).php';
		break;
		case '/ep5temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/ep (5).php';
		break;
		case '/ep6temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/ep (6).php';
		break;
		case '/ep7temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/ep (7).php';
		break;
		case '/ep8temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/ep (8).php';
		break;
		case '/ep9temp2doompatrol':
			include 'comandos/SERIES/doompatrol/temp (2)/ep (9).php';
		break;

		case '/temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (1).php';
		break;
		case '/ep2temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (2).php';
		break;
		case '/ep3temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (3).php';
		break;
		case '/ep4temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (4).php';
		break;
		case '/ep5temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (5).php';
		break;
		case '/ep6temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (6).php';
		break;
		case '/ep7temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (7).php';
		break;
		case '/ep8temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (8).php';
		break;
		case '/ep9temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (9).php';
		break;
		case '/ep10temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (10).php';
		break;
		case '/ep11temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (11).php';
		break;
		case '/ep12temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (12).php';
		break;
		case '/ep13temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (13).php';
		break;
		case '/ep14temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (14).php';
		break;
		case '/ep15temp1doompatrol':
			include 'comandos/SERIES/doompatrol/temp (1)/ep (15).php';
		break;

		case '/temp1devs':
			include 'comandos/SERIES/devs/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1devs':
			include 'comandos/SERIES/devs/temp (1)/ep (1).php';
		break;
		case '/ep2temp1devs':
			include 'comandos/SERIES/devs/temp (1)/ep (2).php';
		break;
		case '/ep3temp1devs':
			include 'comandos/SERIES/devs/temp (1)/ep (3).php';
		break;
		case '/ep4temp1devs':
			include 'comandos/SERIES/devs/temp (1)/ep (4).php';
		break;
		case '/ep5temp1devs':
			include 'comandos/SERIES/devs/temp (1)/ep (5).php';
		break;
		case '/ep6temp1devs':
			include 'comandos/SERIES/devs/temp (1)/ep (6).php';
		break;
		case '/ep7temp1devs':
			include 'comandos/SERIES/devs/temp (1)/ep (7).php';
		break;
		case '/ep8temp1devs':
			include 'comandos/SERIES/devs/temp (1)/ep (8).php';
		break;

		case '/temp3desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (3)/ep (1).php';
		break;
		case '/ep2temp3desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (3)/ep (2).php';
		break;
		case '/ep3temp3desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (3)/ep (3).php';
		break;
		case '/ep4temp3desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (3)/ep (4).php';
		break;
		case '/ep5temp3desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (3)/ep (5).php';
		break;
		case '/ep6temp3desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (3)/ep (6).php';
		break;
		case '/ep7temp3desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (3)/ep (7).php';
		break;

		case '/temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (1).php';
		break;
		case '/ep2temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (2).php';
		break;
		case '/ep3temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (3).php';
		break;
		case '/ep4temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (4).php';
		break;
		case '/ep5temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (5).php';
		break;
		case '/ep6temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (6).php';
		break;
		case '/ep7temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (7).php';
		break;
		case '/ep8temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (8).php';
		break;
		case '/ep9temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (9).php';
		break;
		case '/ep10temp2desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (2)/ep (10).php';
		break;

	        case '/temp1desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (1)/ep (1).php';
		break;
		case '/ep2temp1desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (1)/ep (2).php';
		break;
		case '/ep3temp1desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (1)/ep (3).php';
		break;
		case '/ep4temp1desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (1)/ep (4).php';
		break;
		case '/ep5temp1desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (1)/ep (5).php';
		break;
		case '/ep6temp1desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (1)/ep (6).php';
		break;
		case '/ep7temp1desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (1)/ep (7).php';
		break;
		case '/ep8temp1desventurasemsérie':
			include 'comandos/SERIES/desventurasemsérie/temp (1)/ep (8).php';
		break;

		case '/temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (1).php';
		break;
		case '/ep2temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (2).php';
		break;
		case '/ep3temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (3).php';
		break;
		case '/ep4temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (4).php';
		break;
		case '/ep5temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (5).php';
		break;
		case '/ep6temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (6).php';
		break;
		case '/ep7temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (7).php';
		break;
		case '/ep8temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (8).php';
		break;
		case '/ep9temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (9).php';
		break;
		case '/ep10temp2counterpart':
			include 'comandos/SERIES/counterpart/temp (2)/ep (10).php';
		break;

	        case '/temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (1).php';
		break;
		case '/ep2temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (2).php';
		break;
		case '/ep3temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (3).php';
		break;
		case '/ep4temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (4).php';
		break;
		case '/ep5temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (5).php';
		break;
		case '/ep6temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (6).php';
		break;
		case '/ep7temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (7).php';
		break;
		case '/ep8temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (8).php';
		break;
		case '/ep9temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (9).php';
		break;
		case '/ep10temp1counterpart':
			include 'comandos/SERIES/counterpart/temp (1)/ep (10).php';
		break;

		case '/temp3comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (3)/ep (1).php';
		break;
		case '/ep2temp3comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (3)/ep (2).php';
		break;
		case '/ep3temp3comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (3)/ep (3).php';
		break;
		case '/ep4temp3comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (3)/ep (4).php';
		break;
		case '/ep5temp3comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (3)/ep (5).php';
		break;
		case '/ep6temp3comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (3)/ep (6).php';
		break;

		case '/temp2comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (2)/ep (1).php';
		break;
		case '/ep2temp2comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (2)/ep (2).php';
		break;
		case '/ep3temp2comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (2)/ep (3).php';
		break;
		case '/ep4temp2comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (2)/ep (4).php';
		break;
		case '/ep5temp2comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (2)/ep (5).php';
		break;
		case '/ep6temp2comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (2)/ep (6).php';
		break;

		case '/temp1comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (1)/ep (1).php';
		break;
		case '/ep2temp1comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (1)/ep (2).php';
		break;
		case '/ep3temp1comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (1)/ep (3).php';
		break;
		case '/ep4temp1comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (1)/ep (4).php';
		break;
		case '/ep5temp1comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (1)/ep (5).php';
		break;
		case '/ep6temp1comovenderdrogasonlinerapido':
			include 'comandos/SERIES/comovenderdrogasonlinerapido/temp (1)/ep (6).php';
		break;

		case '/temp1chernobyl':
			include 'comandos/SERIES/chernobyl/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1chernobyl':
			include 'comandos/SERIES/chernobyl/temp (1)/ep (1).php';
		break;
		case '/ep2temp1chernobyl':
			include 'comandos/SERIES/chernobyl/temp (1)/ep (2).php';
		break;
		case '/ep3temp1chernobyl':
			include 'comandos/SERIES/chernobyl/temp (1)/ep (3).php';
		break;
		case '/ep4temp1chernobyl':
			include 'comandos/SERIES/chernobyl/temp (1)/ep (4).php';
		break;
		case '/ep5temp1chernobyl':
			include 'comandos/SERIES/chernobyl/temp (1)/ep (5).php';
		break;
		case '/ep6temp1chernobyl':
			include 'comandos/SERIES/chernobyl/temp (1)/ep (6).php';
		break;
		
		case '/temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/bannertemp4.php';
		break;
		case '/ep1temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (1).php';
		break;
		case '/ep2temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (2).php';
		break;
		case '/ep3temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (3).php';
		break;
		case '/ep4temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (4).php';
		break;
		case '/ep5temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (5).php';
		break;
		case '/ep6temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (6).php';
		break;
		case '/ep7temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (7).php';
		break;
		case '/ep8temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (8).php';
		break;
		case '/ep9temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (9).php';
		break;
		case '/ep10temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (10).php';
		break;
		case '/ep11temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (11).php';
		break;
		case '/ep12temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (12).php';
		break;
		case '/ep13temp4breakingbad':
			include 'comandos/SERIES/breakingbad/temp (4)/ep (13).php';
		break;

		case '/temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/bannertemp5.php';
		break;
		case '/ep1temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (1).php';
		break;
		case '/ep2temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (2).php';
		break;
		case '/ep3temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (3).php';
		break;
		case '/ep4temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (4).php';
		break;
		case '/ep5temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (5).php';
		break;
		case '/ep6temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (6).php';
		break;
		case '/ep7temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (7).php';
		break;
		case '/ep8temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (8).php';
		break;
		case '/ep9temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (9).php';
		break;
		case '/ep10temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (10).php';
		break;
		case '/ep11temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (11).php';
		break;
		case '/ep12temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (12).php';
		break;
		case '/ep13temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (13).php';
		break;
		case '/ep14temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (14).php';
		break;
		case '/ep15temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (15).php';
		break;
		case '/ep16temp5breakingbad':
			include 'comandos/SERIES/breakingbad/temp (5)/ep (16).php';
		break;

		case '/temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (1).php';
		break;
		case '/ep2temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (2).php';
		break;
		case '/ep3temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (3).php';
		break;
		case '/ep4temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (4).php';
		break;
		case '/ep5temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (5).php';
		break;
		case '/ep6temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (6).php';
		break;
		case '/ep7temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (7).php';
		break;
		case '/ep8temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (8).php';
		break;
		case '/ep9temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (9).php';
		break;
		case '/ep10temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (10).php';
		break;
		case '/ep11temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (11).php';
		break;
		case '/ep12temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (12).php';
		break;
		case '/ep13temp3breakingbad':
			include 'comandos/SERIES/breakingbad/temp (3)/ep (13).php';
		break;

		case '/temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (1).php';
		break;
		case '/ep2temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (2).php';
		break;
		case '/ep3temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (3).php';
		break;
		case '/ep4temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (4).php';
		break;
		case '/ep5temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (5).php';
		break;
		case '/ep6temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (6).php';
		break;
		case '/ep7temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (7).php';
		break;
		case '/ep8temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (8).php';
		break;
		case '/ep9temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (9).php';
		break;
		case '/ep10temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (10).php';
		break;
		case '/ep11temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (11).php';
		break;
		case '/ep12temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (12).php';
		break;
		case '/ep13temp2breakingbad':
			include 'comandos/SERIES/breakingbad/temp (2)/ep (13).php';
		break;

		case '/temp1breakingbad':
			include 'comandos/SERIES/breakingbad/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1breakingbad':
			include 'comandos/SERIES/breakingbad/temp (1)/ep (1).php';
		break;
		case '/ep2temp1breakingbad':
			include 'comandos/SERIES/breakingbad/temp (1)/ep (2).php';
		break;
		case '/ep3temp1breakingbad':
			include 'comandos/SERIES/breakingbad/temp (1)/ep (3).php';
		break;
		case '/ep4temp1breakingbad':
			include 'comandos/SERIES/breakingbad/temp (1)/ep (4).php';
		break;
		case '/ep5temp1breakingbad':
			include 'comandos/SERIES/breakingbad/temp (1)/ep (5).php';
		break;
		case '/ep6temp1breakingbad':
			include 'comandos/SERIES/breakingbad/temp (1)/ep (6).php';
		break;
		case '/ep7temp1breakingbad':
			include 'comandos/SERIES/breakingbad/temp (1)/ep (7).php';
		break;

		case '/temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (1).php';
		break;
		case '/ep2temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (2).php';
		break;
		case '/ep3temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (3).php';
		break;
		case '/ep4temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (4).php';
		break;
		case '/ep5temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (5).php';
		break;
		case '/ep6temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (6).php';
		break;
		case '/ep7temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (7).php';
		break;
		case '/ep8temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (8).php';
		break;
		case '/ep9temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (9).php';
		break;
		case '/ep10temp2borgen':
			include 'comandos/SERIES/borgen/temp (2)/ep (10).php';
		break;

		case '/temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (1).php';
		break;
		case '/ep2temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (2).php';
		break;
		case '/ep3temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (3).php';
		break;
		case '/ep4temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (4).php';
		break;
		case '/ep5temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (5).php';
		break;
		case '/ep6temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (6).php';
		break;
		case '/ep7temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (7).php';
		break;
		case '/ep8temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (8).php';
		break;
		case '/ep9temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (9).php';
		break;
		case '/ep10temp1borgen':
			include 'comandos/SERIES/borgen/temp (1)/ep (10).php';
		break;

		case '/temp2barbaros':
			include 'comandos/SERIES/barbaros/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2barbaros':
			include 'comandos/SERIES/barbaros/temp (2)/ep (1).php';
		break;
		case '/ep2temp2barbaros':
			include 'comandos/SERIES/barbaros/temp (2)/ep (2).php';
		break;
		case '/ep3temp2barbaros':
			include 'comandos/SERIES/barbaros/temp (2)/ep (3).php';
		break;
		case '/ep4temp2barbaros':
			include 'comandos/SERIES/barbaros/temp (2)/ep (4).php';
		break;
		case '/ep5temp2barbaros':
			include 'comandos/SERIES/barbaros/temp (2)/ep (5).php';
		break;
		case '/ep6temp2barbaros':
			include 'comandos/SERIES/barbaros/temp (2)/ep (6).php';
		break;

		case '/temp1barbaros':
			include 'comandos/SERIES/barbaros/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1barbaros':
			include 'comandos/SERIES/barbaros/temp (1)/ep (1).php';
		break;
		case '/ep2temp1barbaros':
			include 'comandos/SERIES/barbaros/temp (1)/ep (2).php';
		break;
		case '/ep3temp1barbaros':
			include 'comandos/SERIES/barbaros/temp (1)/ep (3).php';
		break;
		case '/ep4temp1barbaros':
			include 'comandos/SERIES/barbaros/temp (1)/ep (4).php';
		break;
		case '/ep5temp1barbaros':
			include 'comandos/SERIES/barbaros/temp (1)/ep (5).php';
		break;
		case '/ep6temp1barbaros':
			include 'comandos/SERIES/barbaros/temp (1)/ep (6).php';
		break;

		case '/temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (1).php';
		break;
		case '/ep2temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (2).php';
		break;
		case '/ep3temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (3).php';
		break;
		case '/ep4temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (4).php';
		break;
		case '/ep5temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (5).php';
		break;
		case '/ep6temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (6).php';
		break;
		case '/ep7temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (7).php';
		break;
		case '/ep8temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (8).php';
		break;
		case '/ep9temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (9).php';
		break;
		case '/ep10temp1ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (1)/ep (10).php';
		break;

		case '/temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (1).php';
		break;
		case '/ep2temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (2).php';
		break;
		case '/ep3temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (3).php';
		break;
		case '/ep4temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (4).php';
		break;
		case '/ep5temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (5).php';
		break;
		case '/ep6temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (6).php';
		break;
		case '/ep7temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (7).php';
		break;
		case '/ep8temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (8).php';
		break;
		case '/ep9temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (9).php';
		break;
		case '/ep10temp2ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (2)/ep (10).php';
		break;

                case '/temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (1).php';
		break;
		case '/ep2temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (2).php';
		break;
		case '/ep3temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (3).php';
		break;
		case '/ep4temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (4).php';
		break;
		case '/ep5temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (5).php';
		break;
		case '/ep6temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (6).php';
		break;
		case '/ep7temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (7).php';
		break;
		case '/ep8temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (8).php';
		break;
		case '/ep9temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (9).php';
		break;
		case '/ep10temp3ashvsevildead':
			include 'comandos/SERIES/ashvsevildead/temp (3)/ep (10).php';
		break;

		case '/temp1asfloresperdidasdealicehart':
			include 'comandos/SERIES/asfloresperdidasdealicehart/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1asfloresperdidasdealicehart':
			include 'comandos/SERIES/asfloresperdidasdealicehart/temp (1)/ep (1).php';
		break;
		case '/ep2temp1asfloresperdidasdealicehart':
			include 'comandos/SERIES/asfloresperdidasdealicehart/temp (1)/ep (2).php';
		break;
		case '/ep3temp1asfloresperdidasdealicehart':
			include 'comandos/SERIES/asfloresperdidasdealicehart/temp (1)/ep (3).php';
		break;
		case '/ep4temp1asfloresperdidasdealicehart':
			include 'comandos/SERIES/asfloresperdidasdealicehart/temp (1)/ep (4).php';
		break;
		case '/ep5temp1asfloresperdidasdealicehart':
			include 'comandos/SERIES/asfloresperdidasdealicehart/temp (1)/ep (5).php';
		break;
		case '/ep6temp1asfloresperdidasdealicehart':
			include 'comandos/SERIES/asfloresperdidasdealicehart/temp (1)/ep (6).php';
		break;
		case '/ep7temp1asfloresperdidasdealicehart':
			include 'comandos/SERIES/asfloresperdidasdealicehart/temp (1)/ep (7).php';
		break;

		case '/temp1americanvandal':
			include 'comandos/SERIES/americanvandal/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1americanvandal':
			include 'comandos/SERIES/americanvandal/temp (1)/ep (1).php';
		break;
		case '/ep2temp1americanvandal':
			include 'comandos/SERIES/americanvandal/temp (1)/ep (2).php';
		break;
		case '/ep3temp1americanvandal':
			include 'comandos/SERIES/americanvandal/temp (1)/ep (3).php';
		break;
		case '/ep4temp1americanvandal':
			include 'comandos/SERIES/americanvandal/temp (1)/ep (4).php';
		break;
		case '/ep5temp1americanvandal':
			include 'comandos/SERIES/americanvandal/temp (1)/ep (5).php';
		break;
		case '/ep6temp1americanvandal':
			include 'comandos/SERIES/americanvandal/temp (1)/ep (6).php';
		break;
		case '/ep7temp1americanvandal':
			include 'comandos/SERIES/americanvandal/temp (1)/ep (7).php';
		break;
		case '/ep8temp1americanvandal':
			include 'comandos/SERIES/americanvandal/temp (1)/ep (8).php';
		break;

		case '/temp2americanvandal':
			include 'comandos/SERIES/americanvandal/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2americanvandal':
			include 'comandos/SERIES/americanvandal/temp (2)/ep (1).php';
		break;
		case '/ep2temp2americanvandal':
			include 'comandos/SERIES/americanvandal/temp (2)/ep (2).php';
		break;
		case '/ep3temp2americanvandal':
			include 'comandos/SERIES/americanvandal/temp (2)/ep (3).php';
		break;
		case '/ep4temp2americanvandal':
			include 'comandos/SERIES/americanvandal/temp (2)/ep (4).php';
		break;
		case '/ep5temp2americanvandal':
			include 'comandos/SERIES/americanvandal/temp (2)/ep (5).php';
		break;
		case '/ep6temp2americanvandal':
			include 'comandos/SERIES/americanvandal/temp (2)/ep (6).php';
		break;
		case '/ep7temp2americanvandal':
			include 'comandos/SERIES/americanvandal/temp (2)/ep (7).php';
		break;
		case '/ep8temp2americanvandal':
			include 'comandos/SERIES/americanvandal/temp (2)/ep (8).php';
		break;

		case '/ep1temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (1).php';
		break;
		case '/ep2temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (2).php';
		break;
		case '/ep3temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (3).php';
		break;
		case '/ep4temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (4).php';
		break;
		case '/ep5temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (5).php';
		break;
		case '/ep6temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (6).php';
		break;
		case '/ep7temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (7).php';
		break;
		case '/ep8temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (8).php';
		break;
		case '/ep9temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (9).php';
		break;
		case '/ep10temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (10).php';
		break;
		case '/ep11temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (11).php';
		break;
		case '/ep12temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (12).php';
		break;
		case '/ep13temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/ep (13).php';
		break;
		case '/temp112macacos':
			include 'comandos/SERIES/12macacos/temp (1)/bannertemp1.php';
		break;
                case '/temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (1).php';
		break;
		case '/ep2temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (2).php';
		break;
		case '/ep3temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (3).php';
		break;
		case '/ep4temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (4).php';
		break;
		case '/ep5temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (5).php';
		break;
		case '/ep6temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (6).php';
		break;
		case '/ep7temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (7).php';
		break;
		case '/ep8temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (8).php';
		break;
		case '/ep9temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (9).php';
		break;
		case '/ep10temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (10).php';
		break;
		case '/ep11temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (11).php';
		break;
		case '/ep12temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (12).php';
		break;
		case '/ep13temp212macacos':
			include 'comandos/SERIES/12macacos/temp (2)/ep (13).php';
		break;

		case '/temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (1).php';
		break;
		case '/ep2temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (2).php';
		break;
		case '/ep3temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (3).php';
		break;
		case '/ep4temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (4).php';
		break;
		case '/ep5temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (5).php';
		break;
		case '/ep6temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (6).php';
		break;
		case '/ep7temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (7).php';
		break;
		case '/ep8temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (8).php';
		break;
		case '/ep9temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (9).php';
		break;
		case '/ep10temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (10).php';
		break;
		case '/ep11temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (11).php';
		break;
		case '/ep12temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (12).php';
		break;
		case '/ep13temp312macacos':
			include 'comandos/SERIES/12macacos/temp (3)/ep (13).php';
		break;

		case '/temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/bannertemp4.php';
		break;
		case '/ep1temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (1).php';
		break;
		case '/ep2temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (2).php';
		break;
		case '/ep3temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (3).php';
		break;
		case '/ep4temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (4).php';
		break;
		case '/ep5temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (5).php';
		break;
		case '/ep6temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (6).php';
		break;
		case '/ep7temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (7).php';
		break;
		case '/ep8temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (8).php';
		break;
		case '/ep9temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (9).php';
		break;
		case '/ep10temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (10).php';
		break;
		case '/ep11temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (11).php';
		break;
		case '/ep12temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (12).php';
		break;
		case '/ep13temp412macacos':
			include 'comandos/SERIES/12macacos/temp (4)/ep (13).php';
		break;

				case '/temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (1).php';
		break;
		case '/ep2temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (2).php';
		break;
		case '/ep3temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (3).php';
		break;
		case '/ep4temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (4).php';
		break;
		case '/ep5temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (5).php';
		break;
		case '/ep6temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (6).php';
		break;
		case '/ep7temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (7).php';
		break;
		case '/ep8temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (8).php';
		break;
		case '/ep9temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (9).php';
		break;
		case '/ep10temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (10).php';
		break;
		case '/ep11temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (11).php';
		break;
		case '/ep12temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (12).php';
		break;
		case '/ep13temp1aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (1)/ep (13).php';
		break;

				case '/temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (1).php';
		break;
		case '/ep2temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (2).php';
		break;
		case '/ep3temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (3).php';
		break;
		
		case '/ep4temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (4).php';
		break;
		case '/ep5temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (5).php';
		break;
		case '/ep6temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (6).php';
		break;
		case '/ep7temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (7).php';
		break;
		case '/ep8temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (8).php';
		break;
		case '/ep9temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (9).php';
		break;
		case '/ep10temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (10).php';
		break;
		case '/ep11temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (11).php';
		break;
		case '/ep12temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (12).php';
		break;
		case '/ep13temp2aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (2)/ep (13).php';
		break;

				case '/temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (1).php';
		break;
		case '/ep2temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (2).php';
		break;
		case '/ep3temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (3).php';
		break;
		case '/ep4temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (4).php';
		break;
		case '/ep5temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (5).php';
		break;
		case '/ep6temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (6).php';
		break;
		case '/ep7temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (7).php';
		break;
		case '/ep8temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (8).php';
		break;
		case '/ep9temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (9).php';
		break;
		case '/ep10temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (10).php';
		break;
		case '/ep11temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (11).php';
		break;
		case '/ep12temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (12).php';
		break;
		case '/ep13temp3aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (3)/ep (13).php';
		break;

				case '/temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/bannertemp4.php';
		break;
		case '/ep1temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (1).php';
		break;
		case '/ep2temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (2).php';
		break;
		case '/ep3temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (3).php';
		break;
		case '/ep4temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (4).php';
		break;
		case '/ep5temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (5).php';
		break;
		case '/ep6temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (6).php';
		break;
		case '/ep7temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (7).php';
		break;
		case '/ep8temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (8).php';
		break;
		case '/ep9temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (9).php';
		break;
		case '/ep10temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (10).php';
		break;
		case '/ep11temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (11).php';
		break;
		case '/ep12temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (12).php';
		break;
		case '/ep13temp4aamigagenial':
			include 'comandos/SERIES/aamigagenial/temp (4)/ep (13).php';
		break;

				case '/temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (1).php';
		break;
		case '/ep2temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (2).php';
		break;
		case '/ep3temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (3).php';
		break;
		case '/ep4temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (4).php';
		break;
		case '/ep5temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (5).php';
		break;
		case '/ep6temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (6).php';
		break;
		case '/ep7temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (7).php';
		break;
		case '/ep8temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (8).php';
		break;
		case '/ep9temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (9).php';
		break;
		case '/ep10temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (10).php';
		break;
		case '/ep11temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (11).php';
		break;
		case '/ep12temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (12).php';
		break;
		case '/ep13temp1acaçadoradepedófilos':
			include 'comandos/SERIES/acaçadoradepedófilos/temp (1)/ep (13).php';
		break;

		case '/temp1afterlife':
			include 'comandos/SERIES/afterlife/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1afterlife':
			include 'comandos/SERIES/afterlife/temp (1)/ep (1).php';
		break;
		case '/ep2temp1afterlife':
			include 'comandos/SERIES/afterlife/temp (1)/ep (2).php';
		break;
		case '/ep3temp1afterlife':
			include 'comandos/SERIES/afterlife/temp (1)/ep (3).php';
		break;
		case '/ep4temp1afterlife':
			include 'comandos/SERIES/afterlife/temp (1)/ep (4).php';
		break;
		case '/ep5temp1afterlife':
			include 'comandos/SERIES/afterlife/temp (1)/ep (5).php';
		break;
		case '/ep6temp1afterlife':
			include 'comandos/SERIES/afterlife/temp (1)/ep (6).php';
		break;

		case '/temp2afterlife':
			include 'comandos/SERIES/afterlife/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2afterlife':
			include 'comandos/SERIES/afterlife/temp (2)/ep (1).php';
		break;
		case '/ep2temp2afterlife':
			include 'comandos/SERIES/afterlife/temp (2)/ep (2).php';
		break;
		case '/ep3temp2afterlife':
			include 'comandos/SERIES/afterlife/temp (2)/ep (3).php';
		break;
		case '/ep4temp2afterlife':
			include 'comandos/SERIES/afterlife/temp (2)/ep (4).php';
		break;
		case '/ep5temp2afterlife':
			include 'comandos/SERIES/afterlife/temp (2)/ep (5).php';
		break;
		case '/ep6temp2afterlife':
			include 'comandos/SERIES/afterlife/temp (2)/ep (6).php';
		break;

		case '/temp3afterlife':
			include 'comandos/SERIES/afterlife/temp (3)/bannertemp3.php';
		break;
		case '/ep1temp3afterlife':
			include 'comandos/SERIES/afterlife/temp (3)/ep (1).php';
		break;
		case '/ep2temp3afterlife':
			include 'comandos/SERIES/afterlife/temp (3)/ep (2).php';
		break;
		case '/ep3temp3afterlife':
			include 'comandos/SERIES/afterlife/temp (3)/ep (3).php';
		break;
		case '/ep4temp3afterlife':
			include 'comandos/SERIES/afterlife/temp (3)/ep (4).php';
		break;
		case '/ep5temp3afterlife':
			include 'comandos/SERIES/afterlife/temp (3)/ep (5).php';
		break;
		case '/ep6temp3afterlife':
			include 'comandos/SERIES/afterlife/temp (3)/ep (6).php';
		break;

		case '/temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/bannertemp1.php';
		break;
		case '/ep1temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (1).php';
		break;
		case '/ep2temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (2).php';
		break;
		case '/ep3temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (3).php';
		break;
		case '/ep4temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (4).php';
		break;
		case '/ep5temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (5).php';
		break;
		case '/ep6temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (6).php';
		break;
		case '/ep7temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (7).php';
		break;
		case '/ep8temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (8).php';
		break;
		case '/ep9temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (9).php';
		break;
		case '/ep10temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (10).php';
		break;
		case '/ep11temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (11).php';
		break;
		case '/ep12temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (12).php';
		break;
		case '/ep13temp1alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (1)/ep (13).php';
		break;

		case '/temp2alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (2)/bannertemp2.php';
		break;
		case '/ep1temp2alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (2)/ep (1).php';
		break;
		case '/ep2temp2alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (2)/ep (2).php';
		break;
		case '/ep3temp2alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (2)/ep (3).php';
		break;
		case '/ep4temp2alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (2)/ep (4).php';
		break;
		case '/ep5temp2alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (2)/ep (5).php';
		break;
		case '/ep6temp2alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (2)/ep (6).php';
		break;
		case '/ep7temp2alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (2)/ep (7).php';
		break;
		case '/ep8temp2alteredcarbon':
			include 'comandos/SERIES/alteredcarbon/temp (2)/ep (8).php';
		break;

		
		case '/assistir':
			include 'comandos/assistir.php';
		break;

		case '/pedido':
			include 'comandos/pedido.php';
		break;

	    case '/enviarpedido':
			include 'comandos/enviarpedido.php';
		break;		

        case '/termos':
			include 'comandos/termos.php';
		break;

		case '/balance':
		case '/saldo':
		case 'Saldo':
		case 'saldo':
		case '👤 Saldo':
			include 'comandos/saldo.php';
		break;

		case '/suporte':
			include 'comandos/suporte.php';
		break;

		case 'A':
		case '/a':
			include 'comandos/LETRAS/A.php';
		break;

		case 'B':
		case '/b':
			include 'comandos/LETRAS/B.php';
		break;

		case 'C':
		case '/c':
			include 'comandos/LETRAS/C.php';
		break;

		case 'D':
		case '/d':
			include 'comandos/LETRAS/D.php';
		break;

		case 'E':
		case '/e':
			include 'comandos/LETRAS/E.php';
		break;

		case 'F':
		case '/f':
			include 'comandos/LETRAS/F.php';
		break;

		case 'G':
		case '/g':
			include 'comandos/LETRAS/G.php';
		break;

		case 'H':
		case '/h':
			include 'comandos/LETRAS/H.php';
		break;

		case 'I':
		case '/i':
			include 'comandos/LETRAS/I.php';
		break;

		case 'J':
		case '/j':
			include 'comandos/LETRAS/J.php';
		break;

		case 'K':
		case '/k':
			include 'comandos/LETRAS/K.php';
		break;

		case 'L':
		case '/l':
			include 'comandos/LETRAS/L.php';
		break;

		case 'M':
		case '/m':
			include 'comandos/LETRAS/M.php';
		break;

		case 'N':
		case '/n':
			include 'comandos/LETRAS/N.php';
		break;

		case 'O':
		case '/o':
			include 'comandos/LETRAS/O.php';
		break;

		case 'P':
		case '/p':
			include 'comandos/LETRAS/P.php';
		break;

		case 'Q':
		case '/q':
			include 'comandos/LETRAS/Q.php';
		break;

		case 'R':
		case '/r':
			include 'comandos/LETRAS/R.php';
		break;

		case 'S':
		case '/s':
			include 'comandos/LETRAS/S.php';
		break;

		case 'T':
		case '/t':
			include 'comandos/LETRAS/T.php';
		break;

		case 'U':
		case '/u':
			include 'comandos/LETRAS/U.php';
		break;

		case 'V':
		case '/v':
			include 'comandos/LETRAS/V.php';
		break;

		case 'W':
		case '/w':
			include 'comandos/LETRAS/W.php';
		break;

		case 'X':
		case '/x':
			include 'comandos/LETRAS/X.php';
		break;

		case 'Y':
		case '/y':
			include 'comandos/LETRAS/Y.php';
		break;

		case 'Z':
		case '/z':
			include 'comandos/LETRAS/Z.php';
		break;

		case '/':
			include 'comandos/LETRAS/Z.php';
		break;

		case '/pagina2a':
			include 'comandos/LETRAS/pagina2a.php';
		break;

		case '/pagina3a':
			include 'comandos/LETRAS/pagina3a.php';
		break;

		case '/pagina4a':
			include 'comandos/LETRAS/pagina4a.php';
		break;

		case '/pagina5a':
			include 'comandos/LETRAS/pagina5a.php';
		break;

		case '/pagina6a':
			include 'comandos/LETRAS/pagina6a.php';
		break;

		case '/pagina7a':
			include 'comandos/LETRAS/pagina7a.php';
		break;

		case '/pagina8a':
			include 'comandos/LETRAS/pagina8a.php';
		break;

		case '/pagina9a':
			include 'comandos/LETRAS/pagina9a.php';
		break;

		case '#123':
		case '/#123':
			include 'comandos/LETRAS/#123.php';
		break;

		case 'Aquela Canção de Natal':
		case '/aquelacancaodenatal':
			include 'comandos/FILMES/FILMESA/Aquela Canção de Natal.php';
		break;

		case 'A Noite das Vampiras':
		case '/anoitedasvampiras':
			include 'comandos/FILMES/FILMESA/A Noite das Vampiras.php';
		break;

		case 'A Sutil Arte de Ligar o F*da-se':
		case '/asutilartedeligarofodase':
			include 'comandos/FILMES/FILMESA/A Sutil Arte de Ligar o F*da-se.php';
		break;

		case 'A Lista':
		case '/alista':
			include 'comandos/FILMES/FILMESA/A Lista.php';
		break;

		case 'Amizade de Férias 2':
		case '/amizadeferias2':
			include 'comandos/FILMES/FILMESA/Amizade de Férias 2.php';
		break;

		case 'Amor ao Quadrado para Sempre':
		case '/amoraoquadradoparasempre':
			include 'comandos/FILMES/FILMESA/Amor ao Quadrado para Sempre.php';
		break;

		case 'A Dama do Silêncio: La Mataviejitas':
		case '/adamasiliencio':
			include 'comandos/FILMES/FILMESA/A Dama do Silêncio: La Mataviejitas.php';
		break;

		case 'Amor(es) Verdadeiro(s)':
		case '/amorverdairos':
			include 'comandos/FILMES/FILMESA/Amor(es) Verdadeiro(s).php';
		break;

		case 'A Filha da Noiva':
		case '/afilhadanoiva':
			include 'comandos/FILMES/FILMESA/A Filha da Noiva.php';
		break;

		case 'Asteroid City':
		case '/asteroidcity':
			include 'comandos/FILMES/FILMESA/Asteroid City.php';
		break;

		case 'Agente Stone':
		case '/agentestone':
			include 'comandos/FILMES/FILMESA/Agente Stone.php';
		break;

		case 'Arma Secreta':
		case '/armasecreta':
			include 'comandos/FILMES/FILMESA/Arma Secreta.php';
		break;

		case 'Amado':
		case '/amado':
			include 'comandos/FILMES/FILMESA/Amado.php';
		break;

		case 'A Mãe':
		case '/amae':
			include 'comandos/FILMES/FILMESA/A Mãe.php';
		break;

		case 'A Roleta da Morte':
		case '/aroletadamorte':
			include 'comandos/FILMES/FILMESA/A Roleta da Morte.php';
		break;

		case 'A Garota Artificial':
		case '/agarotaartificial':
			include 'comandos/FILMES/FILMESA/A Garota Artificial.php';
		break;

		case 'A Extorsão':
		case '/aextorsao':
			include 'comandos/FILMES/FILMESA/A Extorsão.php';
		break;

		case 'Agente Infiltrado':
		case '/agenteinfiltrado':
			include 'comandos/FILMES/FILMESA/Agente Infiltrado.php';
		break;

		case 'Air: A História Por Trás do Logo':
		case '/airahistóriaportrasdologo':
			include 'comandos/FILMES/FILMESA/Air: A História Por Trás do Logo.php';
		break;

		case 'A Pequena Sereia':
		case '/apequenasereia':
			include 'comandos/FILMES/FILMESA/A Pequena Sereia.php';
		break;

		case 'A Good Person':
		case '/agoodperson':
			include 'comandos/FILMES/FILMESA/A Good Person.php';
		break;

		case 'Among the Beasts':
		case '/amongthebeasts':
			include 'comandos/FILMES/FILMESA/Among the Beasts.php';
		break;

		case 'A Morte do Demônio: A Ascensão':
		case '/amortedodemonioaascensao':
			include 'comandos/FILMES/FILMESA/A Morte do Demônio: A Ascensão.php';
		break;

		case 'A Primeira Comunhão':
		case '/aprimeiracomunhao':
			include 'comandos/FILMES/FILMESA/A Primeira Comunhão.php';
		break;

		case 'Afeganistão: A Retirada':
		case '/afeganistaoaretirada':
			include 'comandos/FILMES/FILMESA/Afeganistão: A Retirada.php';
		break;

		case 'A Baleia':
		case '/abaleia':
			include 'comandos/FILMES/FILMESA/A Baleia.php';
		break;

		case 'Ah, Belinda':
		case '/ahbelinda':
			include 'comandos/FILMES/FILMESA/Ah, Belinda.php';
		break;

		case 'Aftersun':
		case '/aftersun':
			include 'comandos/FILMES/FILMESA/Aftersun.php';
		break;

		case 'Assombrosas':
		case '/assombrosas':
			include 'comandos/FILMES/FILMESA/Assombrosas.php';
		break;

		case 'Alice, Darling':
		case '/alicedarling':
			include 'comandos/FILMES/FILMESA/Alice, Darling.php';
		break;

		case 'As Ondas':
		case '/asondas':
			include 'comandos/FILMES/FILMESA/As Ondas.php';
		break;

		case 'Alguém Que Eu Costumava Conhecer':
		case '/alguemqueeucostumavaconhecer':
			include 'comandos/FILMES/FILMESA/Alguém Que Eu Costumava Conhecer.php';
		break;

		case 'Asterix & Obelix: O Reino do Meio':
		case '/asterix&obelixoreinodomeio':
			include 'comandos/FILMES/FILMESA/Asterix & Obelix: O Reino do Meio.php';
		break;

		case 'Alerta Máximo':
		case '/alertamaximo':
			include 'comandos/FILMES/FILMESA/Alerta Máximo.php';
		break;

		case 'Argentina, 1985':
		case '/argentina1985':
			include 'comandos/FILMES/FILMESA/Argentina, 1985.php';
		break;

		case 'Às Margens':
		case '/asmargens':
			include 'comandos/FILMES/FILMESA/Às Margens.php';
		break;

		case 'Atirador: O Corvo Branco':
		case '/atiradorocorvobranco':
			include 'comandos/FILMES/FILMESA/Atirador: O Corvo Branco.php';
		break;

		case 'Avatar: O Caminho da Água':
		case '/avatarocaminhodaagua':
			include 'comandos/FILMES/FILMESA/Avatar: O Caminho da Água.php';
		break;

		case 'As bestas':
		case '/asbestas':
			include 'comandos/FILMES/FILMESA/As bestas.php';
		break;

		case 'Até os Ossos':
		case '/ateosossos':
			include 'comandos/FILMES/FILMESA/Até os Ossos.php';
		break;

		case 'Aterrorizante 2':
		case '/aterrorizante2':
			include 'comandos/FILMES/FILMESA/Aterrorizante 2.php';
		break;

		case 'As Nadadoras':
		case '/asnadadoras':
			include 'comandos/FILMES/FILMESA/As Nadadoras.php';
		break;

		case 'Adão Negro':
		case '/adaonegro':
			include 'comandos/FILMES/FILMESA/Adão Negro.php';
		break;

		case 'Armageddon Time':
		case '/armageddontime':
			include 'comandos/FILMES/FILMESA/Armageddon Time.php';
		break;

		case 'A Queda':
		case '/aqueda':
			include 'comandos/FILMES/FILMESA/A Queda.php';
		break;

		case 'A Mulher Rei':
		case '/amulherrei':
			include 'comandos/FILMES/FILMESA/A Mulher Rei.php';
		break;

		case 'A Barraca do Beijo (Saga)':
		case '/abarracadobeijosaga':
			include 'comandos/FILMES/FILMESA/A Barraca do Beijo (Saga).php';
		break;

		case 'A Casa Sombria':
		case '/acasasombria':
			include 'comandos/FILMES/FILMESA/A Casa Sombria.php';
		break;

		case 'A Fera':
		case '/afera':
			include 'comandos/FILMES/FILMESA/A Fera.php';
		break;

		case 'A Fita Cassete':
		case '/afitacassete':
			include 'comandos/FILMES/FILMESA/A Fita Cassete.php';
		break;

		case 'After (Saga)':
		case '/afetersaga':
			include 'comandos/FILMES/FILMESA/After (Saga).php';
		break;

		case 'A Extraordinária Garota Chamada Estrela':
		case '/aextraordinariagarotachamadaestrela':
			include 'comandos/FILMES/FILMESA/A Extraordinária Garota Chamada Estrela.php';
		break;

		case 'A Hospedeira':
		case '/ahospedeira':
			include 'comandos/FILMES/FILMESA/A Hospedeira.php';
		break;

		case 'Alerta Vermelho':
		case '/alertavermelho':
			include 'comandos/FILMES/FILMESA/Alerta Vermelho.php';
		break;

		case 'A Múmia (Saga)':
		case '/amumiasaga':
			include 'comandos/FILMES/FILMESA/A Múmia (Saga).php';
		break;

		case 'A Menina Que Matou os Pais':
		case '/ameninaquematouospais':
			include 'comandos/FILMES/FILMESA/A Menina Que Matou os Pais.php';
		break;

		case 'Amor, Sublime Amor':
		case '/amorsublimeamor':
			include 'comandos/FILMES/FILMESA/Amor, Sublime Amor.php';
		break;

		case 'American Underdog':
		case '/americanunderdog':
			include 'comandos/FILMES/FILMESA/American Underdog.php';
		break;

		case 'Animais Fantásticos (Saga)':
		case '/animaisfantasticossaga':
			include 'comandos/FILMES/FILMESA/Animais Fantásticos (Saga).php';
		break;

		case 'Anônimo':
		case '/anonimo':
			include 'comandos/FILMES/FILMESA/Anônimo.php';
		break;

		case 'Attraction (Saga)':
		case '/attractionsaga':
			include 'comandos/FILMES/FILMESA/Attraction (Saga).php';
		break;

		case 'As Branquelas':
		case '/asbranquelas':
			include 'comandos/FILMES/FILMESA/As Branquelas.php';
		break;

		case 'A Princesa e a Plebeia':
		case '/aprincesaeaplebeia':
			include 'comandos/FILMES/FILMESA/A Princesa e a Plebeia.php';
		break;

		case 'Arremessando Alto':
		case '/arremessandoalto':
			include 'comandos/FILMES/FILMESA/Arremessando Alto.php';
		break;

		case 'Ascensão do Cisne Negro':
		case '/ascensaodocisnenegro':
			include 'comandos/FILMES/FILMESA/Ascensão do Cisne Negro.php';
		break;

		case'/barbie':			
			include 'comandos/FILMES/FILMESB/filme1.php';		
		break;			
		case'/besouroazul':			
			include 'comandos/FILMES/FILMESB/filme2.php';		
		break;			
		case'/blondi':			
			include 'comandos/FILMES/FILMESB/filme3.php';		
		break;			
		case'/birdboxbarcelona':			
			include 'comandos/FILMES/FILMESB/filme4.php';		
		break;			
		case'/beautemmedo':			
			include 'comandos/FILMES/FILMESB/filme5.php';		
		break;			
		case'/biggeorgeforeman':			
			include 'comandos/FILMES/FILMESB/filme6.php';		
		break;			
		case'/belodesastre':			
			include 'comandos/FILMES/FILMESB/filme7.php';		
		break;			
		case'/battleforsaipan':			
			include 'comandos/FILMES/FILMESB/filme8.php';		
		break;			
		case'/blonde':			
			include 'comandos/FILMES/FILMESB/filme9.php';		
		break;			
		case'/batmanthedoomthatcametogotham':			
			include 'comandos/FILMES/FILMESB/filme10.php';		
		break;			
		case'/brunoreidalconfessionsofamurderer':			
			include 'comandos/FILMES/FILMESB/filme11.php';		
		break;			
		case'/blood':			
			include 'comandos/FILMES/FILMESB/filme12.php';		
		break;			
		case'/beleza':			
			include 'comandos/FILMES/FILMESB/filme13.php';		
		break;			
		case'/blueback':			
			include 'comandos/FILMES/FILMESB/filme14.php';		
		break;			
		case'/babilonia':			
			include 'comandos/FILMES/FILMESB/filme15.php';		
		break;			
		case'/batemaporta':			
			include 'comandos/FILMES/FILMESB/filme16.php';		
		break;			
		case'/babyruby':			
			include 'comandos/FILMES/FILMESB/filme17.php';		
		break;			
		case'/boyfromheaven':			
			include 'comandos/FILMES/FILMESB/filme18.php';		
		break;			
		case'/bardofalsacronicadealgumasverdades':			
			include 'comandos/FILMES/FILMESB/filme19.php';		
		break;			
		case'/badtrip':			
			include 'comandos/FILMES/FILMESB/filme20.php';		
		break;			
		case'/battleship':			
			include 'comandos/FILMES/FILMESB/filme21.php';		
		break;			
		case'/becket':			
			include 'comandos/FILMES/FILMESB/filme22.php';		
		break;			
		case'/birdbox':			
			include 'comandos/FILMES/FILMESB/filme23.php';		
		break;			
		case'/barbaro':			
			include 'comandos/FILMES/FILMESB/filme24.php';		
		break;			
		case'/badboyssaga':			
			include 'comandos/FILMES/FILMESB/filme25.php';		
		break;			
		case'/biaummundodoavesso':			
			include 'comandos/FILMES/FILMESB/filme26.php';		
		break;			
		case'/brancadeneveeocacadorsaga':			
			include 'comandos/FILMES/FILMESB/filme27.php';		
		break;			
		case'/cemiteriomalditoaorigem':			
			include 'comandos/FILMES/FILMESB/filme27.php';		
		break;			
		case'/criaturasdosenhor':			
			include 'comandos/FILMES/FILMESC/filme1.php';		
		break;			
		case'/cancaodeninar':			
			include 'comandos/FILMES/FILMESC/filme2.php';		
		break;			
		case'/confidentialassignment2international':			
			include 'comandos/FILMES/FILMESC/filme3.php';		
		break;			
		case'/champions':			
			include 'comandos/FILMES/FILMESC/filme4.php';		
		break;			
		case'/chevalier':			
			include 'comandos/FILMES/FILMESC/filme5.php';		
		break;			
		case'/creediii':			
			include 'comandos/FILMES/FILMESC/filme6.php';		
		break;			
		case'/consecration':			
			include 'comandos/FILMES/FILMESC/filme7.php';		
		break;			
		case'/casamentoemfamilia':			
			include 'comandos/FILMES/FILMESC/filme8.php';		
		break;			
		case'/carolofthebells':			
			include 'comandos/FILMES/FILMESC/filme9.php';		
		break;			
		case'/cloudsofchernobyl':			
			include 'comandos/FILMES/FILMESC/filme10.php';		
		break;			
		case'/casamentoarmado':			
			include 'comandos/FILMES/FILMESC/filme11.php';		
		break;			
		case'/christmasbloodychristmas':			
			include 'comandos/FILMES/FILMESC/filme12.php';		
		break;			
		case'/convitemaldito':			
			include 'comandos/FILMES/FILMESC/filme13.php';		
		break;			
		case'/calljane':			
			include 'comandos/FILMES/FILMESC/filme14.php';		
		break;			
		case'/capitaoamericasaga':			
			include 'comandos/FILMES/FILMESC/filme15.php';		
		break;			
		case'/capitamarvel':			
			include 'comandos/FILMES/FILMESC/filme16.php';		
		break;			
		case'/cabrasdapeste':			
			include 'comandos/FILMES/FILMESC/filme17.php';		
		break;			
		case'/campominado':			
			include 'comandos/FILMES/FILMESC/filme18.php';		
		break;			
		case'/carnaval':			
			include 'comandos/FILMES/FILMESC/filme19.php';		
		break;			
		case'/casagucci':			
			include 'comandos/FILMES/FILMESC/filme20.php';		
		break;			
		case'/cherry':			
			include 'comandos/FILMES/FILMESC/filme21.php';		
		break;			
		case'/chuckysaga':			
			include 'comandos/FILMES/FILMESC/filme22.php';		
		break;			
		case'/cidadedegelo':			
			include 'comandos/FILMES/FILMESC/filme23.php';		
		break;			
		case'/cidadeperdida':			
			include 'comandos/FILMES/FILMESC/filme24.php';		
		break;			
		case'/cidadesdepapel':			
			include 'comandos/FILMES/FILMESC/filme25.php';		
		break;			
		case'/cinquentatonssaga':			
			include 'comandos/FILMES/FILMESC/filme26.php';		
		break;			
		case'/circulodefogosaga':			
			include 'comandos/FILMES/FILMESC/filme27.php';		
		break;			
		case'/ceuvermelhosangue':			
			include 'comandos/FILMES/FILMESC/filme28.php';		
		break;			
		case'/corridamortalsaga':			
			include 'comandos/FILMES/FILMESC/filme29.php';		
		break;			
		case'/comamorsimon':			
			include 'comandos/FILMES/FILMESC/filme30.php';		
		break;			
		case'/comoeueraantesdevoce':			
			include 'comandos/FILMES/FILMESC/filme31.php';		
		break;			
		case'/confissoesdeumaadolescenteexcluida':			
			include 'comandos/FILMES/FILMESC/filme32.php';		
		break;			
		case'/comosefosseaprimeiravez':			
			include 'comandos/FILMES/FILMESC/filme33.php';		
		break;			
		case'/coracoesdeferro':			
			include 'comandos/FILMES/FILMESC/filme34.php';		
		break;			
		case'/click':			
			include 'comandos/FILMES/FILMESC/filme35.php';		
		break;			
		case'/coringa':			
			include 'comandos/FILMES/FILMESC/filme36.php';		
		break;			
		case'/corra':			
			include 'comandos/FILMES/FILMESC/filme37.php';		
		break;			
		case'/creedsaga':			
			include 'comandos/FILMES/FILMESC/filme38.php';		
		break;			
		case'/crepusculosaga':			
			include 'comandos/FILMES/FILMESC/filme39.php';		
		break;			
		case'/crimeedesejo':			
			include 'comandos/FILMES/FILMESC/filme40.php';		
		break;			
		case'/crushaaltura':			
			include 'comandos/FILMES/FILMESC/filme41.php';		
		break;			
		case'/cruzada':			
			include 'comandos/FILMES/FILMESC/filme42.php';		
		break;			
		case'/cruzandoalinha':			
			include 'comandos/FILMES/FILMESC/filme43.php';		
		break;			
		case'/dojeitoqueelasquerem2':			
			include 'comandos/FILMES/FILMESC/filme44.php';		
		break;			
		case'/duasbruxasaherancadiabolica':			
			include 'comandos/FILMES/FILMESD/filme1.php';		
		break;			
		case'/deixadosparatrasoiniciodofim':			
			include 'comandos/FILMES/FILMESD/filme2.php';		
		break;			
		case'/dungeons&dragonshonraentrerebeldes':			
			include 'comandos/FILMES/FILMESD/filme3.php';		
		break;			
		case'/desaparecida2023':			
			include 'comandos/FILMES/FILMESD/filme4.php';		
		break;			
		case'/downtonabbeyanewera':			
			include 'comandos/FILMES/FILMESD/filme5.php';		
		break;			
		case'/desaparecida':			
			include 'comandos/FILMES/FILMESD/filme6.php';		
		break;			
		case'/deadstream':			
			include 'comandos/FILMES/FILMESD/filme7.php';		
		break;			
		case'/durodeatuar':			
			include 'comandos/FILMES/FILMESD/filme8.php';		
		break;			
		case'/deferiasdafamilia':			
			include 'comandos/FILMES/FILMESD/filme9.php';		
		break;			
		case'/deadpoolsaga':			
			include 'comandos/FILMES/FILMESD/filme10.php';		
		break;			
		case'/divergentesaga':			
			include 'comandos/FILMES/FILMESD/filme11.php';		
		break;			
		case'/dancarinaimperfeita':			
			include 'comandos/FILMES/FILMESD/filme12.php';		
		break;			
		case'/duna':			
			include 'comandos/FILMES/FILMESD/filme13.php';		
		break;			
		case'/deathnote':			
			include 'comandos/FILMES/FILMESD/filme14.php';		
		break;			
		case'/detetivepikachu':			
			include 'comandos/FILMES/FILMESD/filme15.php';		
		break;			
		case'/devoltaaobaile':			
			include 'comandos/FILMES/FILMESD/filme16.php';		
		break;			
		case'/descendentessaga':			
			include 'comandos/FILMES/FILMESD/filme17.php';		
		break;			
		case'/desventurasemserie':			
			include 'comandos/FILMES/FILMESD/filme18.php';		
		break;			
		case'/devoltaparaofuturosaga':			
			include 'comandos/FILMES/FILMESD/filme19.php';		
		break;			
		case'/diariodeintercambio':			
			include 'comandos/FILMES/FILMESD/filme20.php';		
		break;			
		case'/diariodeumbananasaga':			
			include 'comandos/FILMES/FILMESD/filme21.php';		
		break;			
		case'/dooutroladodalinha':			
			include 'comandos/FILMES/FILMESD/filme22.php';		
		break;			
		case'/dozehomenseoutrosegredo':			
			include 'comandos/FILMES/FILMESD/filme23.php';		
		break;			
		case'/doutorestranhonomultiversodaloucura':			
			include 'comandos/FILMES/FILMESD/filme24.php';		
		break;			
		case'/explorandoodesconhecidoamaquinadotempocosmica':			
			include 'comandos/FILMES/FILMESD/filme25.php';		
		break;			
		case'/emumailhabemdistante':			
			include 'comandos/FILMES/FILMESE/filme1.php';		
		break;			
		case'/eo':			
			include 'comandos/FILMES/FILMESE/filme2.php';		
		break;			
		case'/entremulheres':			
			include 'comandos/FILMES/FILMESE/filme3.php';		
		break;			
		case'/esquemaderiscooperacaofortune':			
			include 'comandos/FILMES/FILMESE/filme4.php';		
		break;			
		case'/emancipationumahistoriadeliberdade':			
			include 'comandos/FILMES/FILMESE/filme5.php';		
		break;			
		case'/eladisse':			
			include 'comandos/FILMES/FILMESE/filme6.php';		
		break;			
		case'/exercitodoamanha':			
			include 'comandos/FILMES/FILMESE/filme7.php';		
		break;			
		case'/escriturariosiii':			
			include 'comandos/FILMES/FILMESE/filme8.php';		
		break;			
		case'/emilyacriminosa':			
			include 'comandos/FILMES/FILMESE/filme9.php';		
		break;			
		case'/enterro':			
			include 'comandos/FILMES/FILMESE/filme10.php';		
		break;			
		case'/eagoramamaesaiudeferias2elevouafamilia':			
			include 'comandos/FILMES/FILMESE/filme11.php';		
		break;			
		case'/eduardo&monica':			
			include 'comandos/FILMES/FILMESE/filme12.php';		
		break;			
		case'/eladisseeledisse':			
			include 'comandos/FILMES/FILMESE/filme13.php';		
		break;			
		case'/elaedemais':			
			include 'comandos/FILMES/FILMESE/filme14.php';		
		break;			
		case'/elcaminoabreakingbadmovie':			
			include 'comandos/FILMES/FILMESE/filme15.php';		
		break;			
		case'/eraumavezemhollywood':			
			include 'comandos/FILMES/FILMESE/filme16.php';		
		break;			
		case'/embuscadesheela':			
			include 'comandos/FILMES/FILMESE/filme17.php';		
		break;			
		case'/emritmodefuga':			
			include 'comandos/FILMES/FILMESE/filme18.php';		
		break;			
		case'/encaixeperfeito':			
			include 'comandos/FILMES/FILMESE/filme19.php';		
		break;			
		case'/enolaholmes':			
			include 'comandos/FILMES/FILMESE/filme20.php';		
		break;			
		case'/escaperoomsaga':			
			include 'comandos/FILMES/FILMESE/filme21.php';		
		break;			
		case'/esquadraosuicidasaga':			
			include 'comandos/FILMES/FILMESE/filme22.php';		
		break;			
		case'/esquadraotrovao':			
			include 'comandos/FILMES/FILMESE/filme23.php';		
		break;			
		case'/esticandoafesta':			
			include 'comandos/FILMES/FILMESE/filme24.php';		
		break;			
		case'/espontanea':			
			include 'comandos/FILMES/FILMESE/filme25.php';		
		break;			
		case'/eternos':			
			include 'comandos/FILMES/FILMESE/filme26.php';		
		break;			
		case'/eurotrip':			
			include 'comandos/FILMES/FILMESE/filme27.php';		
		break;			
		case'/extraordinario':			
			include 'comandos/FILMES/FILMESE/filme28.php';		
		break;			
		case'/exercitodeladroesinvasaodaeuropa':			
			include 'comandos/FILMES/FILMESE/filme29.php';		
		break;			
		case'/eusoualenda':			
			include 'comandos/FILMES/FILMESE/filme30.php';		
		break;			
		case'/eusoutodasasmeninas':			
			include 'comandos/FILMES/FILMESE/filme31.php';		
		break;			
		case'/freira2':			
			include 'comandos/FILMES/FILMESE/filme32.php';		
		break;			
		case'/feriasemtaipei':			
			include 'comandos/FILMES/FILMESF/filme1.php';		
		break;			
		case'/fervo':			
			include 'comandos/FILMES/FILMESF/filme2.php';		
		break;			
		case'/frionosossos':			
			include 'comandos/FILMES/FILMESF/filme3.php';		
		break;			
		case'/flaminhotosaborquemudouahistoria':			
			include 'comandos/FILMES/FILMESF/filme4.php';		
		break;			
		case'/fool?sparadise':			
			include 'comandos/FILMES/FILMESF/filme5.php';		
		break;			
		case'/fenasalturas':			
			include 'comandos/FILMES/FILMESF/filme6.php';		
		break;			
		case'/fomedesucesso':			
			include 'comandos/FILMES/FILMESF/filme7.php';		
		break;			
		case'/freeze':			
			include 'comandos/FILMES/FILMESF/filme8.php';		
		break;			
		case'/furiasfemininas':			
			include 'comandos/FILMES/FILMESF/filme9.php';		
		break;			
		case'/fantasmaecia':			
			include 'comandos/FILMES/FILMESF/filme10.php';		
		break;			
		case'/fear':			
			include 'comandos/FILMES/FILMESF/filme11.php';		
		break;			
		case'/fadamadrinha':			
			include 'comandos/FILMES/FILMESF/filme12.php';		
		break;			
		case'/ferry':			
			include 'comandos/FILMES/FILMESF/filme13.php';		
		break;			
		case'/filhosdeistambul':			
			include 'comandos/FILMES/FILMESF/filme14.php';		
		break;			
		case'/floraeulysses':			
			include 'comandos/FILMES/FILMESF/filme15.php';		
		break;			
		case'/fordvsferrari':			
			include 'comandos/FILMES/FILMESF/filme16.php';		
		break;			
		case'/fresh':			
			include 'comandos/FILMES/FILMESF/filme17.php';		
		break;			
		case'/freeguyassumindoocontrole':			
			include 'comandos/FILMES/FILMESF/filme18.php';		
		break;			
		case'/foradeserie':			
			include 'comandos/FILMES/FILMESF/filme19.php';		
		break;			
		case'/fuja':			
			include 'comandos/FILMES/FILMESF/filme20.php';		
		break;			
		case'/furiaemaltomar':			
			include 'comandos/FILMES/FILMESF/filme21.php';		
		break;			
		case'/granturismodejogadoracorredor':			
			include 'comandos/FILMES/FILMESF/filme22.php';		
		break;			
		case'/guardioesdagalaxiavol3':			
			include 'comandos/FILMES/FILMESG/filme1.php';		
		break;			
		case'/ghostedsemresposta':			
			include 'comandos/FILMES/FILMESG/filme2.php';		
		break;			
		case'/guyritchiesthecovenant':			
			include 'comandos/FILMES/FILMESG/filme3.php';		
		break;			
		case'/guillermodeltoro?spinocchio':			
			include 'comandos/FILMES/FILMESG/filme4.php';		
		break;			
		case'/glassonionummisterioknivesout':			
			include 'comandos/FILMES/FILMESG/filme5.php';		
		break;			
		case'/guardioesdagalaxiaespecialdefestas':			
			include 'comandos/FILMES/FILMESG/filme6.php';		
		break;			
		case'/gigienate':			
			include 'comandos/FILMES/FILMESG/filme7.php';		
		break;			
		case'/galeriadofuturo':			
			include 'comandos/FILMES/FILMESG/filme8.php';		
		break;			
		case'/garotainfernal':			
			include 'comandos/FILMES/FILMESG/filme9.php';		
		break;			
		case'/garotavsmonstro':			
			include 'comandos/FILMES/FILMESG/filme10.php';		
		break;			
		case'/gijoeorigenssnakeeyes':			
			include 'comandos/FILMES/FILMESG/filme11.php';		
		break;			
		case'/guardioesdagalaxiasaga':			
			include 'comandos/FILMES/FILMESG/filme12.php';		
		break;			
		case'/godzilla':			
			include 'comandos/FILMES/FILMESG/filme13.php';		
		break;			
		case'/godzillavskong':			
			include 'comandos/FILMES/FILMESG/filme14.php';		
		break;			
		case'/golpesdevinganca':			
			include 'comandos/FILMES/FILMESG/filme15.php';		
		break;			
		case'/godzillaiireidosmonstros':			
			include 'comandos/FILMES/FILMESG/filme16.php';		
		break;			
		case'/gostosaloucura':			
			include 'comandos/FILMES/FILMESG/filme17.php';		
		break;			
		case'/hormoniosaflordapele':			
			include 'comandos/FILMES/FILMESG/filme18.php';		
		break;			
		case'/homensbrancosnaosabementerrar':			
			include 'comandos/FILMES/FILMESH/filme1.php';		
		break;			
		case'/hypnotic2023':			
			include 'comandos/FILMES/FILMESH/filme2.php';		
		break;			
		case'/huesera':			
			include 'comandos/FILMES/FILMESH/filme3.php';		
		break;			
		case'/huntherkillher':			
			include 'comandos/FILMES/FILMESH/filme4.php';		
		break;			
		case'/homemformigaeavespaquantumania':			
			include 'comandos/FILMES/FILMESH/filme5.php';		
		break;			
		case'/holyspider':			
			include 'comandos/FILMES/FILMESH/filme6.php';		
		break;			
		case'/halloweentown':			
			include 'comandos/FILMES/FILMESH/filme7.php';		
		break;			
		case'/harriet':			
			include 'comandos/FILMES/FILMESH/filme8.php';		
		break;			
		case'/hotseat':			
			include 'comandos/FILMES/FILMESH/filme9.php';		
		break;			
		case'/hypnotic':			
			include 'comandos/FILMES/FILMESH/filme10.php';		
		break;			
		case'/harrypottersaga':			
			include 'comandos/FILMES/FILMESH/filme11.php';		
		break;			
		case'/highschoolmusical':			
			include 'comandos/FILMES/FILMESH/filme12.php';		
		break;			
		case'/hojeeuquerovoltarsozinho':			
			include 'comandos/FILMES/FILMESH/filme13.php';		
		break;			
		case'/homemdeferrosaga':			
			include 'comandos/FILMES/FILMESH/filme14.php';		
		break;			
		case'/homemformigasaga':			
			include 'comandos/FILMES/FILMESH/filme15.php';		
		break;			
		case'/homemaranhasagadotomholland':			
			include 'comandos/FILMES/FILMESH/filme16.php';		
		break;			
		case'/isabellaocasonardoni':			
			include 'comandos/FILMES/FILMESH/filme17.php';		
		break;			
		case'/inquietacao':			
			include 'comandos/FILMES/FILMESI/filme1.php';		
		break;			
		case'/indianajoneseareliquiadodestino':			
			include 'comandos/FILMES/FILMESI/filme2.php';		
		break;			
		case'/inumbernumberoourodejoanesburgo':			
			include 'comandos/FILMES/FILMESI/filme3.php';		
		break;			
		case'/inside':			
			include 'comandos/FILMES/FILMESI/filme4.php';		
		break;			
		case'/innocentvengeance':			
			include 'comandos/FILMES/FILMESI/filme5.php';		
		break;			
		case'/invisiveis':			
			include 'comandos/FILMES/FILMESI/filme6.php';		
		break;			
		case'/irmaosporescolha':			
			include 'comandos/FILMES/FILMESI/filme7.php';		
		break;			
		case'/intheheartofthemachine':			
			include 'comandos/FILMES/FILMESI/filme8.php';		
		break;			
		case'/iwannadancewithsomebodyahistoriadewhitneyhouston':			
			include 'comandos/FILMES/FILMESI/filme9.php';		
		break;			
		case'/infinitypool':			
			include 'comandos/FILMES/FILMESI/filme10.php';		
		break;			
		case'/infiesto':			
			include 'comandos/FILMES/FILMESI/filme11.php';		
		break;			
		case'/irmaosdehonra':			
			include 'comandos/FILMES/FILMESI/filme12.php';		
		break;			
		case'/ingressoparaoparaiso':			
			include 'comandos/FILMES/FILMESI/filme13.php';		
		break;			
		case'/invasaoacasabranca':			
			include 'comandos/FILMES/FILMESI/filme14.php';		
		break;			
		case'/infiltrado':			
			include 'comandos/FILMES/FILMESI/filme15.php';		
		break;			
		case'/imperdoavel':			
			include 'comandos/FILMES/FILMESI/filme16.php';		
		break;			
		case'/infinite':			
			include 'comandos/FILMES/FILMESI/filme17.php';		
		break;			
		case'/interestelar':			
			include 'comandos/FILMES/FILMESI/filme18.php';		
		break;			
		case'/invasaozumbi':			
			include 'comandos/FILMES/FILMESI/filme19.php';		
		break;			
		case'/inverno':			
			include 'comandos/FILMES/FILMESI/filme20.php';		
		break;			
		case'/invasaoaoservicosecreto':			
			include 'comandos/FILMES/FILMESI/filme21.php';		
		break;			
		case'/isoladosmedoinvisivel':			
			include 'comandos/FILMES/FILMESI/filme22.php';		
		break;			
		case'/jackacaixamaldita2odespertar':			
			include 'comandos/FILMES/FILMESI/filme23.php';		
		break;			
		case'/jaestoutevendo':			
			include 'comandos/FILMES/FILMESJ/filme1.php';		
		break;			
		case'/jagunjagunoguerreiro':			
			include 'comandos/FILMES/FILMESJ/filme2.php';		
		break;			
		case'/jogoperfeito':			
			include 'comandos/FILMES/FILMESJ/filme3.php';		
		break;			
		case'/jogodoamor':			
			include 'comandos/FILMES/FILMESJ/filme4.php';		
		break;			
		case'/johnwick4babayaga':			
			include 'comandos/FILMES/FILMESJ/filme5.php';		
		break;			
		case'/jesusrevolution':			
			include 'comandos/FILMES/FILMESJ/filme6.php';		
		break;			
		case'/jung_e':			
			include 'comandos/FILMES/FILMESJ/filme7.php';		
		break;			
		case'/jane':			
			include 'comandos/FILMES/FILMESJ/filme8.php';		
		break;			
		case'/jogosvorazessaga':			
			include 'comandos/FILMES/FILMESJ/filme9.php';		
		break;			
		case'/johnwicksaga':			
			include 'comandos/FILMES/FILMESJ/filme10.php';		
		break;			
		case'/jogoperigoso':			
			include 'comandos/FILMES/FILMESJ/filme11.php';		
		break;			
		case'/jojorabbit':			
			include 'comandos/FILMES/FILMESJ/filme12.php';		
		break;			
		case'/junglecruise':			
			include 'comandos/FILMES/FILMESJ/filme13.php';		
		break;			
		case'/jumanjisaga':			
			include 'comandos/FILMES/FILMESJ/filme14.php';		
		break;			
		case'/jackassparasempre':			
			include 'comandos/FILMES/FILMESJ/filme15.php';		
		break;			
		case'/jurassicworlddominio':			
			include 'comandos/FILMES/FILMESJ/filme16.php';		
		break;			
		case'/jurassicpark':			
			include 'comandos/FILMES/FILMESJ/filme17.php';		
		break;			
		case'/justicaemfamilia':			
			include 'comandos/FILMES/FILMESJ/filme18.php';		
		break;			
		case'/klondikeaguerranaucrania':			
			include 'comandos/FILMES/FILMESJ/filme19.php';		
		break;			
		case'/kingsmansaga':			
			include 'comandos/FILMES/FILMESK/filme1.php';		
		break;			
		case'/kongailhadacaveira':			
			include 'comandos/FILMES/FILMESK/filme2.php';		
		break;			
		case'/killhergoats':			
			include 'comandos/FILMES/FILMESK/filme3.php';		
		break;			
		case'/killboksoon':			
			include 'comandos/FILMES/FILMESK/filme4.php';		
		break;			
		case'/leschosessimples':			
			include 'comandos/FILMES/FILMESK/filme5.php';		
		break;			
		case'/living':			
			include 'comandos/FILMES/FILMESL/filme1.php';		
		break;			
		case'/lutherocairdanoite':			
			include 'comandos/FILMES/FILMESL/filme2.php';		
		break;			
		case'/lilolilocrocodilo':			
			include 'comandos/FILMES/FILMESL/filme3.php';		
		break;			
		case'/lou':			
			include 'comandos/FILMES/FILMESL/filme4.php';		
		break;			
		case'/littledixie':			
			include 'comandos/FILMES/FILMESL/filme5.php';		
		break;			
		case'/ladybird':			
			include 'comandos/FILMES/FILMESL/filme6.php';		
		break;			
		case'/lucy':			
			include 'comandos/FILMES/FILMESL/filme7.php';		
		break;			
		case'/lancesinocentes':			
			include 'comandos/FILMES/FILMESL/filme8.php';		
		break;			
		case'/ligadajusticasnydercut':			
			include 'comandos/FILMES/FILMESL/filme9.php';		
		break;			
		case'/lolita':			
			include 'comandos/FILMES/FILMESL/filme10.php';		
		break;			
		case'/lovecrime':			
			include 'comandos/FILMES/FILMESL/filme11.php';		
		break;			
		case'/lulli':			
			include 'comandos/FILMES/FILMESL/filme12.php';		
		break;			
		case'/missaoimpossivelacertodecontasparte1':			
			include 'comandos/FILMES/FILMESL/filme13.php';		
		break;			
		case'/movimentodejesus':			
			include 'comandos/FILMES/FILMESM/filme1.php';		
		break;			
		case'/madreteresaeeu':			
			include 'comandos/FILMES/FILMESM/filme2.php';		
		break;			
		case'/missaoclandestina':			
			include 'comandos/FILMES/FILMESM/filme3.php';		
		break;			
		case'/meupaieumperigo':			
			include 'comandos/FILMES/FILMESM/filme4.php';		
		break;			
		case'/megatubarao2':			
			include 'comandos/FILMES/FILMESM/filme5.php';		
		break;			
		case'/meualbumdeamores':			
			include 'comandos/FILMES/FILMESM/filme6.php';		
		break;			
		case'/mafiamammaderepentecriminosa':			
			include 'comandos/FILMES/FILMESM/filme7.php';		
		break;			
		case'/minhaculpa':			
			include 'comandos/FILMES/FILMESM/filme8.php';		
		break;			
		case'/malum':			
			include 'comandos/FILMES/FILMESM/filme9.php';		
		break;			
		case'/misterioemparis':			
			include 'comandos/FILMES/FILMESM/filme10.php';		
		break;			
		case'/murilocoutoleso':			
			include 'comandos/FILMES/FILMESM/filme11.php';		
		break;			
		case'/meuamigolutcha':			
			include 'comandos/FILMES/FILMESM/filme12.php';		
		break;			
		case'/mack&rita':			
			include 'comandos/FILMES/FILMESM/filme13.php';		
		break;			
		case'/miiubitameuamor':			
			include 'comandos/FILMES/FILMESM/filme14.php';		
		break;			
		case'/myhappyending':			
			include 'comandos/FILMES/FILMESM/filme15.php';		
		break;			
		case'/maiscedomortodoquecasado':			
			include 'comandos/FILMES/FILMESM/filme16.php';		
		break;			
		case'/magicmike3aultimadanca':			
			include 'comandos/FILMES/FILMESM/filme17.php';		
		break;			
		case'/missing411theufoconnection':			
			include 'comandos/FILMES/FILMESM/filme18.php';		
		break;			
		case'/m3gan':			
			include 'comandos/FILMES/FILMESM/filme19.php';		
		break;			
		case'/moloch':			
			include 'comandos/FILMES/FILMESM/filme20.php';		
		break;			
		case'/mandragora':			
			include 'comandos/FILMES/FILMESM/filme21.php';		
		break;			
		case'/meunomeevinganca':			
			include 'comandos/FILMES/FILMESM/filme22.php';		
		break;			
		case'/maisqueamigos':			
			include 'comandos/FILMES/FILMESM/filme23.php';		
		break;			
		case'/mastemah':			
			include 'comandos/FILMES/FILMESM/filme24.php';		
		break;			
		case'/medieval':			
			include 'comandos/FILMES/FILMESM/filme25.php';		
		break;			
		case'/mortemortemorte':			
			include 'comandos/FILMES/FILMESM/filme26.php';		
		break;			
		case'/madeaoretorno':			
			include 'comandos/FILMES/FILMESM/filme27.php';		
		break;			
		case'/mainstream':			
			include 'comandos/FILMES/FILMESM/filme28.php';		
		break;			
		case'/magicmike':			
			include 'comandos/FILMES/FILMESM/filme29.php';		
		break;			
		case'/malevola':			
			include 'comandos/FILMES/FILMESM/filme30.php';		
		break;			
		case'/maligno':			
			include 'comandos/FILMES/FILMESM/filme31.php';		
		break;			
		case'/madgod':			
			include 'comandos/FILMES/FILMESM/filme32.php';		
		break;			
		case'/matrixsaga':			
			include 'comandos/FILMES/FILMESM/filme33.php';		
		break;			
		case'/mazerunner':			
			include 'comandos/FILMES/FILMESM/filme34.php';		
		break;			
		case'/megatubarao':			
			include 'comandos/FILMES/FILMESM/filme35.php';		
		break;			
		case'/mechamepeloseunome':			
			include 'comandos/FILMES/FILMESM/filme36.php';		
		break;			
		case'/meueternoprimeiroamor':			
			include 'comandos/FILMES/FILMESM/filme37.php';		
		break;			
		case'/medidaprovisoria':			
			include 'comandos/FILMES/FILMESM/filme38.php';		
		break;			
		case'/meninasmalvadas':			
			include 'comandos/FILMES/FILMESM/filme39.php';		
		break;			
		case'/mentessombrias':			
			include 'comandos/FILMES/FILMESM/filme40.php';		
		break;			
		case'/meuprimeiroamor':			
			include 'comandos/FILMES/FILMESM/filme41.php';		
		break;			
		case'/milagrenacela7':			
			include 'comandos/FILMES/FILMESM/filme42.php';		
		break;			
		case'/missaoimpossivel':			
			include 'comandos/FILMES/FILMESM/filme43.php';		
		break;			
		case'/minhamaeeumapecatrilogia':			
			include 'comandos/FILMES/FILMESM/filme44.php';		
		break;			
		case'/minorityreportanovalei':			
			include 'comandos/FILMES/FILMESM/filme45.php';		
		break;			
		case'/moonfallameacalunar':			
			include 'comandos/FILMES/FILMESM/filme46.php';		
		break;			
		case'/muitoalemdoslimites':			
			include 'comandos/FILMES/FILMESM/filme47.php';		
		break;			
		case'/morbius':			
			include 'comandos/FILMES/FILMESM/filme48.php';		
		break;			
		case'/mortalkombat':			
			include 'comandos/FILMES/FILMESM/filme49.php';		
		break;			
		case'/mulan':			
			include 'comandos/FILMES/FILMESM/filme50.php';		
		break;			
		case'/mommyslittlestar':			
			include 'comandos/FILMES/FILMESM/filme51.php';		
		break;			
		case'/mulhermaravilha':			
			include 'comandos/FILMES/FILMESM/filme52.php';		
		break;			
		case'/mrnobody':			
			include 'comandos/FILMES/FILMESM/filme53.php';		
		break;			
		case'/noitesangrenta':			
			include 'comandos/FILMES/FILMESM/filme54.php';		
		break;			
		case'/nossoamigoextraordinario':			
			include 'comandos/FILMES/FILMESN/filme1.php';		
		break;			
		case'/ninguemvaitesalvar':			
			include 'comandos/FILMES/FILMESN/filme2.php';		
		break;			
		case'/nikkienoragemeasemacao':			
			include 'comandos/FILMES/FILMESN/filme3.php';		
		break;			
		case'/noritmodafe':			
			include 'comandos/FILMES/FILMESN/filme4.php';		
		break;			
		case'/nocebo':			
			include 'comandos/FILMES/FILMESN/filme5.php';		
		break;			
		case'/noitepassadaemsoho':			
			include 'comandos/FILMES/FILMESN/filme6.php';		
		break;			
		case'/napalmadamao':			
			include 'comandos/FILMES/FILMESN/filme7.php';		
		break;			
		case'/nasuacasaounaminha':			
			include 'comandos/FILMES/FILMESN/filme8.php';		
		break;			
		case'/nomiresalosojos':			
			include 'comandos/FILMES/FILMESN/filme9.php';		
		break;			
		case'/novembre':			
			include 'comandos/FILMES/FILMESN/filme10.php';		
		break;			
		case'/nefarious':			
			include 'comandos/FILMES/FILMESN/filme11.php';		
		break;			
		case'/nanny':			
			include 'comandos/FILMES/FILMESN/filme12.php';		
		break;			
		case'/noiteinfeliz':			
			include 'comandos/FILMES/FILMESN/filme13.php';		
		break;			
		case'/naosepreocupequerida':			
			include 'comandos/FILMES/FILMESN/filme14.php';		
		break;			
		case'/nabatidadocoracao':			
			include 'comandos/FILMES/FILMESN/filme15.php';		
		break;			
		case'/namiradoperigo':			
			include 'comandos/FILMES/FILMESN/filme16.php';		
		break;			
		case'/nanaturezaselvagem':			
			include 'comandos/FILMES/FILMESN/filme17.php';		
		break;			
		case'/naofecheosolhos':			
			include 'comandos/FILMES/FILMESN/filme18.php';		
		break;			
		case'/naomemate':			
			include 'comandos/FILMES/FILMESN/filme19.php';		
		break;			
		case'/naoolheparacima':			
			include 'comandos/FILMES/FILMESN/filme20.php';		
		break;			
		case'/naoolhe':			
			include 'comandos/FILMES/FILMESN/filme21.php';		
		break;			
		case'/needforspeed':			
			include 'comandos/FILMES/FILMESN/filme22.php';		
		break;			
		case'/ninfomaniaca':			
			include 'comandos/FILMES/FILMESN/filme23.php';		
		break;			
		case'/oestranhocasodofantasmaclaustrofobico':			
			include 'comandos/FILMES/FILMESN/filme24.php';		
		break;			
		case'/oclubedeleitoresassassinos':			
			include 'comandos/FILMES/FILMESO/filme1.php';		
		break;			
		case'/oneranger':			
			include 'comandos/FILMES/FILMESO/filme2.php';		
		break;			
		case'/oamormandoumensagem':			
			include 'comandos/FILMES/FILMESO/filme3.php';		
		break;			
		case'/ostresmosqueteirosdartagnan':			
			include 'comandos/FILMES/FILMESO/filme4.php';		
		break;			
		case'/ochamado4':			
			include 'comandos/FILMES/FILMESO/filme5.php';		
		break;			
		case'/oesquadraosuicida':			
			include 'comandos/FILMES/FILMESO/filme6.php';		
		break;			
		case'/odemoniodosmares':			
			include 'comandos/FILMES/FILMESO/filme7.php';		
		break;			
		case'/ohomemdacabana':			
			include 'comandos/FILMES/FILMESO/filme8.php';		
		break;			
		case'/oqueeumamulher':			
			include 'comandos/FILMES/FILMESO/filme9.php';		
		break;			
		case'/oultimoduelo':			
			include 'comandos/FILMES/FILMESO/filme10.php';		
		break;			
		case'/oscavaleirosdozodiacosaintseiyaocomeco':			
			include 'comandos/FILMES/FILMESO/filme11.php';		
		break;			
		case'/ogenioeolouco':			
			include 'comandos/FILMES/FILMESO/filme12.php';		
		break;			
		case'/ovilarejo':			
			include 'comandos/FILMES/FILMESO/filme13.php';		
		break;			
		case'/outofexile':			
			include 'comandos/FILMES/FILMESO/filme14.php';		
		break;			
		case'/operationnapoleon':			
			include 'comandos/FILMES/FILMESO/filme15.php';		
		break;			
		case'/onedayasalion':			
			include 'comandos/FILMES/FILMESO/filme16.php';		
		break;			
		case'/oexorcistadopapa':			
			include 'comandos/FILMES/FILMESO/filme17.php';		
		break;			
		case'/oestranguladordeboston':			
			include 'comandos/FILMES/FILMESO/filme18.php';		
		break;			
		case'/oursodopobranco':			
			include 'comandos/FILMES/FILMESO/filme19.php';		
		break;			
		case'/ohomemdonorte':			
			include 'comandos/FILMES/FILMESO/filme20.php';		
		break;			
		case'/oolhodomal':			
			include 'comandos/FILMES/FILMESO/filme21.php';		
		break;			
		case'/ovelho':			
			include 'comandos/FILMES/FILMESO/filme22.php';		
		break;			
		case'/objetos':			
			include 'comandos/FILMES/FILMESO/filme23.php';		
		break;			
		case'/opiorvizinhodomundo':			
			include 'comandos/FILMES/FILMESO/filme24.php';		
		break;			
		case'/opalidoolhoazul':			
			include 'comandos/FILMES/FILMESO/filme25.php';		
		break;			
		case'/oferendaaodemonio':			
			include 'comandos/FILMES/FILMESO/filme26.php';		
		break;			
		case'/osbansheesdeinisherin':			
			include 'comandos/FILMES/FILMESO/filme27.php';		
		break;			
		case'/osfabelmans':			
			include 'comandos/FILMES/FILMESO/filme28.php';		
		break;			
		case'/oamantedeladychatterley':			
			include 'comandos/FILMES/FILMESO/filme29.php';		
		break;			
		case'/omilagre':			
			include 'comandos/FILMES/FILMESO/filme30.php';		
		break;			
		case'/odiariodenoel':			
			include 'comandos/FILMES/FILMESO/filme31.php';		
		break;			
		case'/omenu':			
			include 'comandos/FILMES/FILMESO/filme32.php';		
		break;			
		case'/operacaocerveja':			
			include 'comandos/FILMES/FILMESO/filme33.php';		
		break;			
		case'/oexecutor':			
			include 'comandos/FILMES/FILMESO/filme34.php';		
		break;			
		case'/orecifeperseguido':			
			include 'comandos/FILMES/FILMESO/filme35.php';		
		break;			
		case'/olhosfamintosrenascido':			
			include 'comandos/FILMES/FILMESO/filme36.php';		
		break;			
		case'/oamormoveondas':			
			include 'comandos/FILMES/FILMESO/filme37.php';		
		break;			
		case'/oceuestaemtodolugar':			
			include 'comandos/FILMES/FILMESO/filme38.php';		
		break;			
		case'/odilonoreudesimesmo':			
			include 'comandos/FILMES/FILMESO/filme39.php';		
		break;			
		case'/oprecodaseducao':			
			include 'comandos/FILMES/FILMESO/filme40.php';		
		break;			
		case'/observadores':			
			include 'comandos/FILMES/FILMESO/filme41.php';		
		break;			
		case'/ochapeleirolouco':			
			include 'comandos/FILMES/FILMESO/filme42.php';		
		break;			
		case'/ohobbit':			
			include 'comandos/FILMES/FILMESO/filme43.php';		
		break;			
		case'/ocacadordepipas':			
			include 'comandos/FILMES/FILMESO/filme44.php';		
		break;			
		case'/ocomecodavida':			
			include 'comandos/FILMES/FILMESO/filme45.php';		
		break;			
		case'/odiariodeprincesa':			
			include 'comandos/FILMES/FILMESO/filme46.php';		
		break;			
		case'/ogolpistadotinder':			
			include 'comandos/FILMES/FILMESO/filme47.php';		
		break;			
		case'/oxigenio':			
			include 'comandos/FILMES/FILMESO/filme48.php';		
		break;			
		case'/ohomemnastrevas':			
			include 'comandos/FILMES/FILMESO/filme49.php';		
		break;			
		case'/oodioquevocesemeia':			
			include 'comandos/FILMES/FILMESO/filme50.php';		
		break;			
		case'/ohomemideal':			
			include 'comandos/FILMES/FILMESO/filme51.php';		
		break;			
		case'/oincrivelhulk':			
			include 'comandos/FILMES/FILMESO/filme52.php';		
		break;			
		case'/operfumista':			
			include 'comandos/FILMES/FILMESO/filme53.php';		
		break;			
		case'/oexterminadordofuturosaga':			
			include 'comandos/FILMES/FILMESO/filme54.php';		
		break;			
		case'/olardascriancaspeculiares':			
			include 'comandos/FILMES/FILMESO/filme55.php';		
		break;			
		case'/olobodewallstreet':			
			include 'comandos/FILMES/FILMESO/filme56.php';		
		break;			
		case'/omassacredaserraeletricaoretornodeleatherface':			
			include 'comandos/FILMES/FILMESO/filme57.php';		
		break;			
		case'/osmercenarios':			
			include 'comandos/FILMES/FILMESO/filme58.php';		
		break;			
		case'/omelhorlance':			
			include 'comandos/FILMES/FILMESO/filme59.php';		
		break;			
		case'/osnovosmutantes':			
			include 'comandos/FILMES/FILMESO/filme60.php';		
		break;			
		case'/omundodosesquecidos':			
			include 'comandos/FILMES/FILMESO/filme61.php';		
		break;			
		case'/onovissimotestamento':			
			include 'comandos/FILMES/FILMESO/filme62.php';		
		break;			
		case'/omeninoquematoumeuspais':			
			include 'comandos/FILMES/FILMESO/filme63.php';		
		break;			
		case'/omeninodopijamalistrado':			
			include 'comandos/FILMES/FILMESO/filme64.php';		
		break;			
		case'/omeninoquedescobriuovento':			
			include 'comandos/FILMES/FILMESO/filme65.php';		
		break;			
		case'/omisteriodacasaassombrada':			
			include 'comandos/FILMES/FILMESO/filme66.php';		
		break;			
		case'/opoderosochefao':			
			include 'comandos/FILMES/FILMESO/filme67.php';		
		break;			
		case'/oreidoshow':			
			include 'comandos/FILMES/FILMESO/filme68.php';		
		break;			
		case'/osenhordosaneis':			
			include 'comandos/FILMES/FILMESO/filme69.php';		
		break;			
		case'/osestagiarios':			
			include 'comandos/FILMES/FILMESO/filme70.php';		
		break;			
		case'/osrenegados':			
			include 'comandos/FILMES/FILMESO/filme71.php';		
		break;			
		case'/otelefonepreto':			
			include 'comandos/FILMES/FILMESO/filme72.php';		
		break;			
		case'/opredador':			
			include 'comandos/FILMES/FILMESO/filme73.php';		
		break;			
		case'/opoco':			
			include 'comandos/FILMES/FILMESO/filme74.php';		
		break;			
		case'/oreino':			
			include 'comandos/FILMES/FILMESO/filme75.php';		
		break;			
		case'/osintrusos':			
			include 'comandos/FILMES/FILMESO/filme76.php';		
		break;			
		case'/ovendedordesonhos':			
			include 'comandos/FILMES/FILMESO/filme77.php';		
		break;			
		case'/osvingadoressaga':			
			include 'comandos/FILMES/FILMESO/filme78.php';		
		break;			
		case'/paraiso':			
			include 'comandos/FILMES/FILMESP/filme1.php';		
		break;			
		case'/paint':			
			include 'comandos/FILMES/FILMESP/filme2.php';		
		break;			
		case'/papaiepop':			
			include 'comandos/FILMES/FILMESP/filme3.php';		
		break;			
		case'/projetoextracao':			
			include 'comandos/FILMES/FILMESP/filme4.php';		
		break;			
		case'/piscinainfinita':			
			include 'comandos/FILMES/FILMESP/filme5.php';		
		break;			
		case'/peterpanewendy':			
			include 'comandos/FILMES/FILMESP/filme6.php';		
		break;			
		case'/pornhubsexobilionario':			
			include 'comandos/FILMES/FILMESP/filme7.php';		
		break;			
		case'/primeiroamoroultimoyakuza':			
			include 'comandos/FILMES/FILMESP/filme8.php';		
		break;			
		case'/punch':			
			include 'comandos/FILMES/FILMESP/filme9.php';		
		break;			
		case'/panicovi':			
			include 'comandos/FILMES/FILMESP/filme10.php';		
		break;			
		case'/projetocacaaolobo':			
			include 'comandos/FILMES/FILMESP/filme11.php';		
		break;			
		case'/passagem':			
			include 'comandos/FILMES/FILMESP/filme12.php';		
		break;			
		case'/playdead':			
			include 'comandos/FILMES/FILMESP/filme13.php';		
		break;			
		case'/porquinha':			
			include 'comandos/FILMES/FILMESP/filme14.php';		
		break;			
		case'/panteranegrawakandaparasempre':			
			include 'comandos/FILMES/FILMESP/filme15.php';		
		break;			
		case'/planodeaula':			
			include 'comandos/FILMES/FILMESP/filme16.php';		
		break;			
		case'/pearl':			
			include 'comandos/FILMES/FILMESP/filme17.php';		
		break;			
		case'/paisdedeus':			
			include 'comandos/FILMES/FILMESP/filme18.php';		
		break;			
		case'/paratodososgarotosqueamei':			
			include 'comandos/FILMES/FILMESP/filme19.php';		
		break;			
		case'/panico':			
			include 'comandos/FILMES/FILMESP/filme20.php';		
		break;			
		case'/parasempre':			
			include 'comandos/FILMES/FILMESP/filme21.php';		
		break;			
		case'/panteranegra':			
			include 'comandos/FILMES/FILMESP/filme22.php';		
		break;			
		case'/percyjacksoneoladraoderaios':			
			include 'comandos/FILMES/FILMESP/filme23.php';		
		break;			
		case'/pedrocoelho':			
			include 'comandos/FILMES/FILMESP/filme24.php';		
		break;			
		case'/perseguicao':			
			include 'comandos/FILMES/FILMESP/filme25.php';		
		break;			
		case'/pinoquio':			
			include 'comandos/FILMES/FILMESP/filme26.php';		
		break;			
		case'/piratasdocaribe':			
			include 'comandos/FILMES/FILMESP/filme27.php';		
		break;			
		case'/planosdiabolicos':			
			include 'comandos/FILMES/FILMESP/filme28.php';		
		break;			
		case'/podersemlimites':			
			include 'comandos/FILMES/FILMESP/filme29.php';		
		break;			
		case'/ponteparaterabitia':			
			include 'comandos/FILMES/FILMESP/filme30.php';		
		break;			
		case'/psicopataamericano':			
			include 'comandos/FILMES/FILMESP/filme31.php';		
		break;			
		case'/quehoraseutepego':			
			include 'comandos/FILMES/FILMESQ/filme1.php';		
		break;			
		case'/quandoasluzesseapagam':			
			include 'comandos/FILMES/FILMESQ/filme2.php';		
		break;			
		case'/queridoevanhansen':			
			include 'comandos/FILMES/FILMESQ/filme3.php';		
		break;			
		case'/quatroamigasnumafria':			
			include 'comandos/FILMES/FILMESQ/filme4.php';		
		break;			
		case'/resgateemmedelin':			
			include 'comandos/FILMES/FILMESR/filme1.php';		
		break;			
		case'/rrr':			
			include 'comandos/FILMES/FILMESR/filme2.php';		
		break;			
		case'/resgate2':			
			include 'comandos/FILMES/FILMESR/filme3.php';		
		break;			
		case'/rmn':			
			include 'comandos/FILMES/FILMESR/filme4.php';		
		break;			
		case'/renfielddandoosanguepelochefe':			
			include 'comandos/FILMES/FILMESR/filme5.php';		
		break;			
		case'/raquel11':			
			include 'comandos/FILMES/FILMESR/filme6.php';		
		break;			
		case'/rainhasemfuga':			
			include 'comandos/FILMES/FILMESR/filme7.php';		
		break;			
		case'/ruidobranco':			
			include 'comandos/FILMES/FILMESR/filme8.php';		
		break;			
		case'/ripd2riseofthedamned':			
			include 'comandos/FILMES/FILMESR/filme9.php';		
		break;			
		case'/residentevilsaga':			
			include 'comandos/FILMES/FILMESR/filme10.php';		
		break;			
		case'/resistencia':			
			include 'comandos/FILMES/FILMESR/filme11.php';		
		break;			
		case'/ritmodefuga':			
			include 'comandos/FILMES/FILMESR/filme12.php';		
		break;			
		case'/rogaipornos':			
			include 'comandos/FILMES/FILMESR/filme13.php';		
		break;			
		case'/rotadefugasaga':			
			include 'comandos/FILMES/FILMESR/filme14.php';		
		break;			
		case'/rubikon':			
			include 'comandos/FILMES/FILMESR/filme15.php';		
		break;			
		case'/reflexoesdeumliquidificador':			
			include 'comandos/FILMES/FILMESR/filme16.php';		
		break;			
		case'/ruadomedotrilogia':			
			include 'comandos/FILMES/FILMESR/filme17.php';		
		break;			
		case'/streetflow2':			
			include 'comandos/FILMES/FILMESS/filme1.php';		
		break;			
		case'/shootingstarsavidadelebronjames':			
			include 'comandos/FILMES/FILMESS/filme2.php';		
		break;			
		case'/sosmamisofilme':			
			include 'comandos/FILMES/FILMESS/filme3.php';		
		break;			
		case'/sinaldivino':			
			include 'comandos/FILMES/FILMESS/filme4.php';		
		break;			
		case'/somdaliberdade':			
			include 'comandos/FILMES/FILMESS/filme5.php';		
		break;			
		case'/sedeassassina':			
			include 'comandos/FILMES/FILMESS/filme6.php';		
		break;			
		case'/substitutos':			
			include 'comandos/FILMES/FILMESS/filme7.php';		
		break;			
		case'/shazamfuriadosdeuses':			
			include 'comandos/FILMES/FILMESS/filme8.php';		
		break;			
		case'/simulant':			
			include 'comandos/FILMES/FILMESS/filme9.php';		
		break;			
		case'/sayen':			
			include 'comandos/FILMES/FILMESS/filme10.php';		
		break;			
		case'/shecamefromthewoods':			
			include 'comandos/FILMES/FILMESS/filme11.php';		
		break;			
		case'/sombrasdeumcrime':			
			include 'comandos/FILMES/FILMESS/filme12.php';		
		break;			
		case'/sisu':			
			include 'comandos/FILMES/FILMESS/filme13.php';		
		break;			
		case'/sharper':			
			include 'comandos/FILMES/FILMESS/filme14.php';		
		break;			
		case'/snowangel':			
			include 'comandos/FILMES/FILMESS/filme15.php';		
		break;			
		case'/sick':			
			include 'comandos/FILMES/FILMESS/filme16.php';		
		break;			
		case'/somethinginthedirt':			
			include 'comandos/FILMES/FILMESS/filme17.php';		
		break;			
		case'/satansslaves2communion':			
			include 'comandos/FILMES/FILMESS/filme18.php';		
		break;			
		case'/srrobertdowney':			
			include 'comandos/FILMES/FILMESS/filme19.php';		
		break;			
		case'/sorria':			
			include 'comandos/FILMES/FILMESS/filme20.php';		
		break;			
		case'/samaritano':			
			include 'comandos/FILMES/FILMESS/filme21.php';		
		break;			
		case'/savagesalvation':			
			include 'comandos/FILMES/FILMESS/filme22.php';		
		break;			
		case'/setehomenseumdestino':			
			include 'comandos/FILMES/FILMESS/filme23.php';		
		break;			
		case'/semlimites':			
			include 'comandos/FILMES/FILMESS/filme24.php';		
		break;			
		case'/semremorso':			
			include 'comandos/FILMES/FILMESS/filme25.php';		
		break;			
		case'/seeuficar':			
			include 'comandos/FILMES/FILMESS/filme26.php';		
		break;			
		case'/shazam':			
			include 'comandos/FILMES/FILMESS/filme27.php';		
		break;			
		case'/shangchiealendadosdezaneis':			
			include 'comandos/FILMES/FILMESS/filme28.php';		
		break;			
		case'/sierraburgesseumaloser':			
			include 'comandos/FILMES/FILMESS/filme29.php';		
		break;			
		case'/simplismenteacontece':			
			include 'comandos/FILMES/FILMESS/filme30.php';		
		break;			
		case'/sozinha':			
			include 'comandos/FILMES/FILMESS/filme31.php';		
		break;			
		case'/sonicsaga':			
			include 'comandos/FILMES/FILMESS/filme32.php';		
		break;			
		case'/spin':			
			include 'comandos/FILMES/FILMESS/filme33.php';		
		break;			
		case'/swindle':			
			include 'comandos/FILMES/FILMESS/filme34.php';		
		break;			
		case'/sobrevivaoumorratentando':			
			include 'comandos/FILMES/FILMESS/filme35.php';		
		break;			
		case'/spacejamumnovolegado':			
			include 'comandos/FILMES/FILMESS/filme36.php';		
		break;			
		case'/tudosobdescontrole':			
			include 'comandos/FILMES/FILMEST/filme1.php';		
		break;			
		case'/tresbabasparaonatal':			
			include 'comandos/FILMES/FILMEST/filme2.php';		
		break;			
		case'/taticasdoamor':			
			include 'comandos/FILMES/FILMEST/filme3.php';		
		break;			
		case'/teslaohomemeletrico':			
			include 'comandos/FILMES/FILMEST/filme4.php';		
		break;			
		case'/thecursed':			
			include 'comandos/FILMES/FILMEST/filme5.php';		
		break;			
		case'/theflash':			
			include 'comandos/FILMES/FILMEST/filme6.php';		
		break;			
		case'/transformersodespertardasferas':			
			include 'comandos/FILMES/FILMEST/filme7.php';		
		break;			
		case'/transfusao':			
			include 'comandos/FILMES/FILMEST/filme8.php';		
		break;			
		case'/thehangingsun':			
			include 'comandos/FILMES/FILMEST/filme9.php';		
		break;			
		case'/tictacamaternidadedomal':			
			include 'comandos/FILMES/FILMEST/filme10.php';		
		break;			
		case'/tudopelanoiva':			
			include 'comandos/FILMES/FILMEST/filme11.php';		
		break;			
		case'/theconference':			
			include 'comandos/FILMES/FILMEST/filme12.php';		
		break;			
		case'/tin&tina':			
			include 'comandos/FILMES/FILMEST/filme13.php';		
		break;			
		case'/thelastkingdomsevenkingsmustdie':			
			include 'comandos/FILMES/FILMEST/filme14.php';		
		break;			
		case'/theblackdemon':			
			include 'comandos/FILMES/FILMEST/filme15.php';		
		break;			
		case'/tudoporumponto':			
			include 'comandos/FILMES/FILMEST/filme16.php';		
		break;			
		case'/terraaderiva2':			
			include 'comandos/FILMES/FILMEST/filme17.php';		
		break;			
		case'/tetris':			
			include 'comandos/FILMES/FILMEST/filme18.php';		
		break;			
		case'/thelostking':			
			include 'comandos/FILMES/FILMEST/filme19.php';		
		break;			
		case'/thepointmen':			
			include 'comandos/FILMES/FILMEST/filme20.php';		
		break;			
		case'/thereading':			
			include 'comandos/FILMES/FILMEST/filme21.php';		
		break;			
		case'/thedonorparty':			
			include 'comandos/FILMES/FILMEST/filme22.php';		
		break;			
		case'/theritualkiller':			
			include 'comandos/FILMES/FILMEST/filme23.php';		
		break;			
		case'/theintegrityofjosephchambers':			
			include 'comandos/FILMES/FILMEST/filme24.php';		
		break;			
		case'/teenwolfofilme':			
			include 'comandos/FILMES/FILMEST/filme25.php';		
		break;			
		case'/thedevilconspiracy':			
			include 'comandos/FILMES/FILMEST/filme26.php';		
		break;			
		case'/theressomethingwrongwiththechildren':			
			include 'comandos/FILMES/FILMEST/filme27.php';		
		break;			
		case'/themeanone':			
			include 'comandos/FILMES/FILMEST/filme28.php';		
		break;			
		case'/theapology':			
			include 'comandos/FILMES/FILMEST/filme29.php';		
		break;			
		case'/togethertogether':			
			include 'comandos/FILMES/FILMEST/filme30.php';		
		break;			
		case'/theeternaldaughter':			
			include 'comandos/FILMES/FILMEST/filme31.php';		
		break;			
		case'/tillabuscaporjustica':			
			include 'comandos/FILMES/FILMEST/filme32.php';		
		break;			
		case'/troll':			
			include 'comandos/FILMES/FILMEST/filme33.php';		
		break;			
		case'/trembala':			
			include 'comandos/FILMES/FILMEST/filme34.php';		
		break;			
		case'/tudoporjojo':			
			include 'comandos/FILMES/FILMEST/filme35.php';		
		break;			
		case'/threethousandyearsoflonging':			
			include 'comandos/FILMES/FILMEST/filme36.php';		
		break;			
		case'/triangulodatristeza':			
			include 'comandos/FILMES/FILMEST/filme37.php';		
		break;			
		case'/talvezumahistoriadeamor':			
			include 'comandos/FILMES/FILMEST/filme38.php';		
		break;			
		case'/taxidriver':			
			include 'comandos/FILMES/FILMEST/filme39.php';		
		break;			
		case'/teenbeach':			
			include 'comandos/FILMES/FILMEST/filme40.php';		
		break;			
		case'/tempo':			
			include 'comandos/FILMES/FILMEST/filme41.php';		
		break;			
		case'/theassault':			
			include 'comandos/FILMES/FILMEST/filme42.php';		
		break;			
		case'/thoramorytrueno':			
			include 'comandos/FILMES/FILMEST/filme43.php';		
		break;			
		case'/thorgodofthunder':			
			include 'comandos/FILMES/FILMEST/filme44.php';		
		break;			
		case'/thecolourroom':			
			include 'comandos/FILMES/FILMEST/filme45.php';		
		break;			
		case'/titanic':			
			include 'comandos/FILMES/FILMEST/filme46.php';		
		break;			
		case'/ticktickboom':			
			include 'comandos/FILMES/FILMEST/filme47.php';		
		break;			
		case'/ticoetecodefensoresdalei':			
			include 'comandos/FILMES/FILMEST/filme48.php';		
		break;			
		case'/tinidepoisdevioletta':			
			include 'comandos/FILMES/FILMEST/filme49.php';		
		break;			
		case'/tom&jerry':			
			include 'comandos/FILMES/FILMEST/filme50.php';		
		break;			
		case'/transformerssaga':			
			include 'comandos/FILMES/FILMEST/filme51.php';		
		break;			
		case'/tornhearts':			
			include 'comandos/FILMES/FILMEST/filme52.php';		
		break;			
		case'/tratamentoderealeza':			
			include 'comandos/FILMES/FILMEST/filme53.php';		
		break;			
		case'/turmadamonicalicoes':			
			include 'comandos/FILMES/FILMEST/filme54.php';		
		break;			
		case'/tqm':			
			include 'comandos/FILMES/FILMEST/filme55.php';		
		break;			
		case'/tudoporela':			
			include 'comandos/FILMES/FILMEST/filme56.php';		
		break;			
		case'/twitches':			
			include 'comandos/FILMES/FILMEST/filme57.php';		
		break;			
		case'/umanoinesquecivel':			
			include 'comandos/FILMES/FILMESU/filme1.php';		
		break;			
		case'/ufosweden':			
			include 'comandos/FILMES/FILMESU/filme2.php';		
		break;			
		case'/unseen':			
			include 'comandos/FILMES/FILMESU/filme3.php';		
		break;			
		case'/unwelcome':			
			include 'comandos/FILMES/FILMESU/filme4.php';		
		break;			
		case'/umfilho':			
			include 'comandos/FILMES/FILMESU/filme5.php';		
		break;			
		case'/umanoitenomuseuoretornodekahmunrah':			
			include 'comandos/FILMES/FILMESU/filme6.php';		
		break;			
		case'/umhomemdeacao':			
			include 'comandos/FILMES/FILMESU/filme7.php';		
		break;			
		case'/umahistoriadenatalnatalina':			
			include 'comandos/FILMES/FILMESU/filme8.php';		
		break;			
		case'/umamorpararecordar':			
			include 'comandos/FILMES/FILMESU/filme9.php';		
		break;			
		case'/umdiarioparajordan':			
			include 'comandos/FILMES/FILMESU/filme10.php';		
		break;			
		case'/umcrushparaonatal':			
			include 'comandos/FILMES/FILMESU/filme11.php';		
		break;			
		case'/umfuneralemfamilia':			
			include 'comandos/FILMES/FILMESU/filme12.php';		
		break;			
		case'/umdiaparasempre':			
			include 'comandos/FILMES/FILMESU/filme13.php';		
		break;			
		case'/ummatchsurpresa':			
			include 'comandos/FILMES/FILMESU/filme14.php';		
		break;			
		case'/umninhoparadois':			
			include 'comandos/FILMES/FILMESU/filme15.php';		
		break;			
		case'/umlugarsilenciososaga':			
			include 'comandos/FILMES/FILMESU/filme16.php';		
		break;			
		case'/umreencontroinesperado':			
			include 'comandos/FILMES/FILMESU/filme17.php';		
		break;			
		case'/umadobranotempo':			
			include 'comandos/FILMES/FILMESU/filme18.php';		
		break;			
		case'/umavozcontraopoder':			
			include 'comandos/FILMES/FILMESU/filme19.php';		
		break;			
		case'/ummundoencantado':			
			include 'comandos/FILMES/FILMESU/filme20.php';		
		break;			
		case'/umanoitedecrimesaga':			
			include 'comandos/FILMES/FILMESU/filme21.php';		
		break;			
		case'/umavidacomproposito':			
			include 'comandos/FILMES/FILMESU/filme22.php';		
		break;			
		case'/uncharted':			
			include 'comandos/FILMES/FILMESU/filme23.php';		
		break;			
		case'/vocenaotaconvidadapromeubatmitzva':			
			include 'comandos/FILMES/FILMESV/filme1.php';		
		break;			
		case'/vermelhobrancoesangueazul':			
			include 'comandos/FILMES/FILMESV/filme2.php';		
		break;			
		case'/velozesefuriosos10':			
			include 'comandos/FILMES/FILMESV/filme3.php';		
		break;			
		case'/viejos':			
			include 'comandos/FILMES/FILMESV/filme4.php';		
		break;			
		case'/vicioperfeito':			
			include 'comandos/FILMES/FILMESV/filme5.php';		
		break;			
		case'/valedomedo':			
			include 'comandos/FILMES/FILMESV/filme6.php';		
		break;			
		case'/vikingulven':			
			include 'comandos/FILMES/FILMESV/filme7.php';		
		break;			
		case'/venus':			
			include 'comandos/FILMES/FILMESV/filme8.php';		
		break;			
		case'/viuvanegra':			
			include 'comandos/FILMES/FILMESV/filme9.php';		
		break;			
		case'/vesper':			
			include 'comandos/FILMES/FILMESV/filme10.php';		
		break;			
		case'/venom2filmes':			
			include 'comandos/FILMES/FILMESV/filme11.php';		
		break;			
		case'/vidro':			
			include 'comandos/FILMES/FILMESV/filme12.php';		
		break;			
		case'/velozesefuriosossaga':			
			include 'comandos/FILMES/FILMESV/filme13.php';		
		break;			
		case'/vejacomoelescorrem':			
			include 'comandos/FILMES/FILMESV/filme14.php';		
		break;			
		case'/whoinvitedcharlie':			
			include 'comandos/FILMES/FILMESW/filme1.php';		
		break;			
		case'/whinderssonnunesissonaoeumculto':			
			include 'comandos/FILMES/FILMESW/filme2.php';		
		break;			
		case'/winniethepoohbloodandhoney':			
			include 'comandos/FILMES/FILMESW/filme3.php';		
		break;			
		case'/wandavisionofilme':			
			include 'comandos/FILMES/FILMESW/filme4.php';		
		break;			
		case'/watchmenofilme':			
			include 'comandos/FILMES/FILMESW/filme5.php';		
		break;			
		case'/whinderssonnunesedemimmesmo':			
			include 'comandos/FILMES/FILMESW/filme6.php';		
		break;			
		case'/xamarcadamorte':			
			include 'comandos/FILMES/FILMESX/filme1.php';		
		break;			
		case'/xtreme':			
			include 'comandos/FILMES/FILMESX/filme2.php';		
		break;			
		case'/youpeople':			
			include 'comandos/FILMES/FILMESY/filme1.php';		
		break;			
		case'/yesterday':			
			include 'comandos/FILMES/FILMESY/filme2.php';		
		break;			
		case'/zoeetempestade':			
			include 'comandos/FILMES/FILMESZ/filme1.php';		
		break;			
		case'/zohan':			
			include 'comandos/FILMES/FILMESZ/filme2.php';		
		break;			
		case'/zombies':			
			include 'comandos/FILMES/FILMESZ/filme3.php';		
		break;			
		case'/zoey102ocasamento':			
			include 'comandos/FILMES/FILMESZ/filme4.php';		
		break;			

		case '↩️ Voltar':
			include 'comandos/start.php';
		break;

		case '/recarregar':
		case 'Recarga':
		case 'Recarregar':
		case '💴 Recarregar':
		case '/assinar':
			include 'comandos/recarregar.php';
		break;

		case '/resgatar':
			include 'comandos/resgatar.php';
		break;

		case '/totaladicionados':
                case '🤖 totaladd':
			include 'comandos/totaladicionados.php';
		break;

		case '/afiliado':
		case '/afiliados':
		case '/referencias':
		case '✔️ afiliados':
			include 'comandos/afiliados.php';
		break;

		case '/comprar':
			include 'comandos/comprar.php';
		break;

		// parte dedicada ao dono do bot

		case '/addsaldo':
			include 'comandos/addsaldo.php';
		break;

		case '/removesaldo':
			include 'comandos/removesaldo.php';
		break;

		case '/removeblock':
			include 'comandos/removeblock.php';
		break;

		case '/addresgate':
			include 'comandos/addresgate.php';
		break;

        case '/enviar':
			include 'comandos/enviar.php';
		break;

		case '/getsaldo':
			include 'comandos/getsaldo.php';
		break;

	endswitch;

endfor;
