<?php

if ($user['saldo'] == 49.90) {
    // Se o saldo for igual a 49.90, encaminhe a mensagem normalmente
    $msg = $tlg->copyMessage([
        'chat_id' => $tlg->ChatID(),
        'from_chat_id' => -1001928605290, // Substitua pelo chat ID correto
        'message_id' => 85,
        'protect_content' => true, // Proteção contra encaminhamento
		'reply_markup' => $tlg->buildInlineKeyboard ([
			[
				$tlg->buildInlineKeyBoardButton ("✅ JA ASSISTIR", null, "/assistir")
			],
			[
				$tlg->buildInlineKeyBoardButton ("🗂 CATÁLOGO", null, "/catalogo")
			]
		])
		
		
    ]);

    if ($msg['ok']) {
        // Se o saldo for suficiente, exibimos a mensagem de sucesso
        $tlg->sendMessage([
            'chat_id' => '-1002015224084',
            'text' => "Alguém Solicitou Um Filme!\nID usuário: {$tlg->ChatID()}\n👤 Username: @{$tlg->Username ()}",
        ]);

    } else {
        // Se ocorrer algum erro ao encaminhar a mensagem, notificamos o usuário
        $tlg->sendMessage([
            'chat_id' => '-1002015224084',
            'text' => "Erro ao enviar Filme Aquela Canção de Natal",
            'parse_mode' => 'html'
        ]);
    }
} else {
    // Se o saldo não for igual a 0 nem 49.90, notificamos o usuário
    $tlg->sendMessage([
        'chat_id' => $tlg->ChatID(),
        'text' => "<b>Seu Saldo não é suficiente para acessar este conteúdo.\n\nPara aderir a um teste de 1 hora, entre em contato com nosso suporte.</b>",
        'parse_mode' => 'html',
        'message_id' => $tlg->MessageID (),
        'disable_web_page_preview' => 'true',
        'reply_markup' => $tlg->buildInlineKeyboard ([
            [
                $tlg->buildInlineKeyBoardButton ('💸 ASSINAR', null, '/recarregar'),
                $tlg->buildInlineKeyBoardButton ('☎️ SUPORTE', null, '/suporte')
            ],
            [
                $tlg->buildInlineKeyBoardButton ('↩️ VOLTAR', null, "/catalogo")
            ],
        ])
    ]);
}

// Verifique se a ação é acionada por um callback
if ($tlg->Callback_ID() !== null) {
    // Exclua a mensagem anterior
    $tlg->deleteMessage([
        'chat_id' => $tlg->ChatID(),
        'message_id' => $tlg->MessageID(),
    ]);
    
    // Envie a nova mensagem com a imagem atualizada e os botões
    $tlg->sendPhoto($dados_mensagem2);
} else {
    // Envie a mensagem normal se não for um callback
    $tlg->sendPhoto($dados_mensagem);

}
?>
