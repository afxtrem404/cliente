<?php
// Verifica o saldo para decidir se exibe o botão
if ($user['saldo'] == 49.90) {
    $botoes = [
        [
            $tlg->buildInlineKeyBoardButton('▶️ ASSISTIR', 'https://t.me/+DZC_T6wTMoowZDlh', null),
        ],
        [
            $tlg->buildInlineKeyBoardButton('🗂 CATÁLOGO', null,'/catalogo'),
        ],
    ];
} else {
    // Se o saldo não for igual a 10, não adicionamos nenhum botão
    $botoes = [
        [
            $tlg->buildInlineKeyBoardButton('Você Não Tem Saldo Suficiente', null, '/recarregar'),
        ],
    ];
}

$dados_mensagem = [
    'chat_id' => $tlg->ChatID(),
    'photo' => 'https://ibb.co/K0s95z9', // Substitua pela URL da sua imagem
    'caption' => "Sua mensagem de texto aqui",
    'parse_mode' => 'html',
    'disable_web_page_preview' => 'false',
    'reply_markup' => $tlg->buildInlineKeyboard($botoes),
];

// Use a função sendPhoto para enviar a foto
$tlg->sendPhoto($dados_mensagem);
?>