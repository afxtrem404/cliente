<?php
$bd_tlg->setPais ($tlg->UserID (), $id_pais);
$id_pais = (PAISES [$complemento]) ? $complemento : 73;
	$pais = PAISES [$id_pais];
$saldo = (string)number_format ($user ['saldo'], 2);
$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "📜 <b>Olá ".htmlentities ($tlg->FirstName ())."</b>,  Seja bem-vindo (a)!\n\n▫️ · Meu usuario é @suleimansmsbot e fui desenvolvido com a finalidade de receber diversos SMS\n\n🔸 · Informações\n\n🏴 · Pais Selecionado: {$pais}\n💲 - Meu Saldo:<code> R\${$saldo}</code>\n🏆 - Meu ID: <code>{$tlg->UserID ()}</code>\n\n\n🛎 · Afim de trabalhar conosco?, acesse nosso grupo abaixo!\n\n<b><em><a href=\"https://t.me/suleiman171\">👨🏾‍💻 SUPORTE</a></em></b>\n<b><em><a href=\"https://t.me/ryzerccstores\">🏅 · GRUPO</a></em></b>",
	'parse_mode' => 'html',
	'disable_web_page_preview' => true,
	'reply_markup' => $tlg->buildKeyBoard ([
		[$tlg->buildInlineKeyboardButton ('Aquela Canção de Natal'),],
		[$tlg->buildInlineKeyboardButton ('A Noite das Vampiras'),$tlg->buildInlineKeyboardButton ('A Sutil Arte de Ligar o F*da-se'),],
		[$tlg->buildInlineKeyboardButton ('A Lista'),$tlg->buildInlineKeyboardButton ('Amizade de Férias 2'),],
		[$tlg->buildInlineKeyboardButton ('Amor ao Quadrado para Sempre'),],
		[$tlg->buildInlineKeyboardButton ('A Dama do Silêncio: La Mataviejitas'),],
		[$tlg->buildInlineKeyboardButton ('Amor(es) Verdadeiro(s)'),$tlg->buildInlineKeyboardButton ('A Filha da Noiva'),],
		[$tlg->buildInlineKeyboardButton ('Asteroid City'),$tlg->buildInlineKeyboardButton ('Agente Stone'),$tlg->buildInlineKeyboardButton ('Arma Secreta'),],
		[$tlg->buildInlineKeyboardButton ('Amado'), $tlg->buildInlineKeyboardButton ('A Mãe'),$tlg->buildInlineKeyboardButton ('A Roleta da Morte'),],
		[$tlg->buildInlineKeyboardButton ('A Garota Artificial'),$tlg->buildInlineKeyboardButton ('A Extorsão'),$tlg->buildInlineKeyboardButton ('Agente Infiltrado'),],
		[$tlg->buildInlineKeyboardButton ('Air: A História Por Trás do Logo'),],
		[$tlg->buildInlineKeyboardButton ('A Pequena Sereia'),$tlg->buildInlineKeyboardButton ('A Good Person'),$tlg->buildInlineKeyboardButton ('Among the Beasts'),],
		[$tlg->buildInlineKeyboardButton ('A Morte do Demônio: A Ascensão'),],
		[$tlg->buildInlineKeyboardButton ('A Primeira Comunhão'),$tlg->buildInlineKeyboardButton ('Afeganistão: A Retirada'),],
		[$tlg->buildInlineKeyboardButton ('A Baleia'),$tlg->buildInlineKeyboardButton ('Ah, Belinda'),$tlg->buildInlineKeyboardButton ('Aftersun'),],
		[$tlg->buildInlineKeyboardButton ('Assombrosas'),$tlg->buildInlineKeyboardButton ('Alice, Darling'),$tlg->buildInlineKeyboardButton ('As Ondas'),],
		[$tlg->buildInlineKeyboardButton ('Alguém Que Eu Costumava Conhecer'),],
		[$tlg->buildInlineKeyboardButton ('Asterix & Obelix: O Reino do Meio'),],
		[$tlg->buildInlineKeyboardButton ('Alerta Máximo'), $tlg->buildInlineKeyboardButton ('Argentina, 1985'),$tlg->buildInlineKeyboardButton ('Às Margens'),],
		[$tlg->buildInlineKeyboardButton ('Atirador: O Corvo Branco'),$tlg->buildInlineKeyboardButton ('Avatar: O Caminho da Água'),],
		[$tlg->buildInlineKeyboardButton ('As bestas'),$tlg->buildInlineKeyboardButton ('Até os Ossos'),],
		[$tlg->buildInlineKeyboardButton ('Aterrorizante 2'),$tlg->buildInlineKeyboardButton ('As Nadadoras'),$tlg->buildInlineKeyboardButton ('Adão Negro'),],
		[$tlg->buildInlineKeyboardButton ('Armageddon Time'), $tlg->buildInlineKeyboardButton ('A Queda'),$tlg->buildInlineKeyboardButton ('A Mulher Rei'),],
		[$tlg->buildInlineKeyboardButton ('A Barraca do Beijo (Saga)'),$tlg->buildInlineKeyboardButton ('A Casa Sombria'),],
		[$tlg->buildInlineKeyboardButton ('A Fera'),$tlg->buildInlineKeyboardButton ('A Fita Cassete'), $tlg->buildInlineKeyboardButton ('After (Saga)'),],
		[$tlg->buildInlineKeyboardButton ('A Extraordinária Garota Chamada Estrela'),],
		[$tlg->buildInlineKeyboardButton ('A Hospedeira'),$tlg->buildInlineKeyboardButton ('Alerta Vermelho'),$tlg->buildInlineKeyboardButton ('A Múmia (Saga)'),],
		[$tlg->buildInlineKeyboardButton ('A Menina Que Matou os Pais'), $tlg->buildInlineKeyboardButton ('Amor, Sublime Amor'),],
		[$tlg->buildInlineKeyboardButton ('American Underdog'), $tlg->buildInlineKeyboardButton ('Animais Fantásticos (Saga)'),],
		[$tlg->buildInlineKeyboardButton ('Anônimo'), $tlg->buildInlineKeyboardButton ('Attraction (Saga)'),$tlg->buildInlineKeyboardButton ('As Branquelas'),],
		[$tlg->buildInlineKeyboardButton ('A Princesa e a Plebeia'),$tlg->buildInlineKeyboardButton ('Arremessando Alto'),],
		[$tlg->buildInlineKeyboardButton ('Ascensão do Cisne Negro'),],
		[$tlg->buildInlineKeyBoardButton ('↩️ Voltar', null, "/start")]
	], true, true)
]);

// afiliados
if (isset ($complemento) && is_numeric ($complemento) && STATUS_AFILIADO){

	$ref = $tlg->getUsuarioTlg ($complemento);

	// se usuario existir e não tiver entrado no bot por indicação de alguem e tambem não pode ser ele mesmo
	if (isset ($ref ['id']) && $bd_tlg->checkReferencia ($tlg->UserID ()) == false && $complemento != $tlg->UserID ()){

		// salva usuario atual como referencia do dono do link
		$bd_tlg->setReferencia ($complemento, $tlg->UserID ());

	}

}