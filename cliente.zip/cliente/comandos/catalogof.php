<?php
$bd_tlg->setPais($tlg->UserID(), $id_pais);
$id_pais = (PAISES[$complemento]) ? $complemento : 73;
$pais = PAISES[$id_pais];
$saldo = (string)number_format($user['saldo'], 2);

// URL da imagem que você deseja enviar
$foto_url = 'https://i.ibb.co/2y068hh/7.jpg';

// Mensagem de texto que acompanha a imagem
$mensagem = "<b>Bem-vindo(a)!</b> 😊 Aqui você pode encontrar filmes e séries organizados por suas letras iniciais.\n\nSimplesmente escolha uma letra e comece a explorar! 🎬✨";

// Crie o array $dados_mensagem com a foto
$dados_mensagem2 = [
    'chat_id' => $tlg->ChatID(),
    'photo' => $foto_url,
    'caption' => $mensagem,
    'parse_mode' => 'html',
    'disable_web_page_preview' => true,
    'reply_markup' => $tlg->buildInlineKeyboard([
		[
			$tlg->buildInlineKeyboardButton ('A', null, "/a"), $tlg->buildInlineKeyboardButton ('B', null, "/b"),$tlg->buildInlineKeyboardButton ('C', null, "/c"),$tlg->buildInlineKeyboardButton ('D', null, "/d"),$tlg->buildInlineKeyboardButton ('E', null, "/e"),
		],
		[
			$tlg->buildInlineKeyboardButton ('F', null, "/f"),$tlg->buildInlineKeyboardButton ('G', null, "/g"), $tlg->buildInlineKeyboardButton ('H', null, "/h"),$tlg->buildInlineKeyboardButton ('I', null, "/i"),$tlg->buildInlineKeyboardButton ('J', null, "/j"),
		],
		[
			$tlg->buildInlineKeyboardButton ('K', null, "/k"),$tlg->buildInlineKeyboardButton ('L', null, "/l"),$tlg->buildInlineKeyboardButton ('M', null, "/m"), $tlg->buildInlineKeyboardButton ('N', null, "/n"),$tlg->buildInlineKeyboardButton ('O', null, "/o"),
	    ],
		[
			$tlg->buildInlineKeyboardButton ('P', null, "/p"),$tlg->buildInlineKeyboardButton ('Q', null, "/q"),$tlg->buildInlineKeyboardButton ('R', null, "/r"),$tlg->buildInlineKeyboardButton ('S', null, "/s"), $tlg->buildInlineKeyboardButton ('T', null, "/t"),
		],
		[
			$tlg->buildInlineKeyboardButton ('U', null, "/u"),$tlg->buildInlineKeyboardButton ('V', null, "/v"),$tlg->buildInlineKeyboardButton ('W', null, "/w"),$tlg->buildInlineKeyboardButton ('X', null, "/x"),$tlg->buildInlineKeyboardButton ('Y', null, "/y"),
		],
		[
            $tlg->buildInlineKeyboardButton ('Z', null, "/z"),$tlg->buildInlineKeyboardButton ('#123', null, "/#123"),
		],
        [
            $tlg->buildInlineKeyBoardButton ('↩️ Voltar ', null, "/start"), $tlg->buildInlineKeyBoardButton ('📞 Suporte ', null, "/suporte")
        ],
		])
	];
// Crie o array $dados_mensagem com a foto
$dados_mensagem = [
    'chat_id' => $tlg->ChatID(),
    'photo' => $foto_url,
    'caption' => $mensagem,
    'parse_mode' => 'html',
    'disable_web_page_preview' => true,
    'reply_markup' => $tlg->buildInlineKeyboard([
		[
			$tlg->buildInlineKeyboardButton ('A', null, "/a"), $tlg->buildInlineKeyboardButton ('B', null, "/b"),$tlg->buildInlineKeyboardButton ('C', null, "/c"),$tlg->buildInlineKeyboardButton ('D', null, "/d"),$tlg->buildInlineKeyboardButton ('E', null, "/e"),
		],
		[
			$tlg->buildInlineKeyboardButton ('F', null, "/f"),$tlg->buildInlineKeyboardButton ('G', null, "/g"), $tlg->buildInlineKeyboardButton ('H', null, "/h"),$tlg->buildInlineKeyboardButton ('I', null, "/i"),$tlg->buildInlineKeyboardButton ('J', null, "/j"),
		],
		[
			$tlg->buildInlineKeyboardButton ('K', null, "/k"),$tlg->buildInlineKeyboardButton ('L', null, "/l"),$tlg->buildInlineKeyboardButton ('M', null, "/m"), $tlg->buildInlineKeyboardButton ('N', null, "/n"),$tlg->buildInlineKeyboardButton ('O', null, "/o"),
	    ],
		[
			$tlg->buildInlineKeyboardButton ('P', null, "/p"),$tlg->buildInlineKeyboardButton ('Q', null, "/q"),$tlg->buildInlineKeyboardButton ('R', null, "/r"),$tlg->buildInlineKeyboardButton ('S', null, "/s"), $tlg->buildInlineKeyboardButton ('T', null, "/t"),
		],
		[
			$tlg->buildInlineKeyboardButton ('U', null, "/u"),$tlg->buildInlineKeyboardButton ('V', null, "/v"),$tlg->buildInlineKeyboardButton ('W', null, "/w"),$tlg->buildInlineKeyboardButton ('X', null, "/x"),$tlg->buildInlineKeyboardButton ('Y', null, "/y"),
		],
		[
            $tlg->buildInlineKeyboardButton ('Z', null, "/z"),$tlg->buildInlineKeyboardButton ('#123', null, "/#123"),
		],
        [
            $tlg->buildInlineKeyBoardButton ('↩️ Voltar ', null, "/start"), $tlg->buildInlineKeyBoardButton ('📞 Suporte ', null, "/suporte")
        ],
		])
	];

// Verifique se a ação é acionada por um callback
if ($tlg->Callback_ID() !== null) {
    // Exclua a mensagem anterior
    $tlg->deleteMessage([
        'chat_id' => $tlg->ChatID(),
        'message_id' => $tlg->MessageID(),
    ]);
    
    // Envie a nova mensagem com a imagem atualizada e os botões
    $tlg->sendPhoto($dados_mensagem2);
} else {
    // Envie a mensagem normal se não for um callback
    $tlg->sendPhoto($dados_mensagem);

}
?>
