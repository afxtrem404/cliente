<?php
$bd_tlg->setPais($tlg->UserID(), $id_pais);
$id_pais = (PAISES[$complemento]) ? $complemento : 73;
$pais = PAISES[$id_pais];
$saldo = (string)number_format($user['saldo'], 2);

// URL da imagem que você deseja enviar
$foto_url = 'https://i.ibb.co/2y068hh/7.jpg';

// Mensagem de texto que acompanha a imagem
$mensagem = "<b>Bem-vindo(a)!</b> 😊 Aqui você pode encontrar séries disponíveis.\n\nSimplesmente escolha uma letra e comece a explorar! 🎬✨";

// Crie o array $dados_mensagem com a foto
$dados_mensagem2 = [
    'chat_id' => $tlg->ChatID(),
    'photo' => $foto_url,
    'caption' => $mensagem,
    'parse_mode' => 'html',
    'disable_web_page_preview' => true,
	'reply_markup' => $tlg->buildInlineKeyboard([
		[
			$tlg->buildInlineKeyboardButton ('Bárbaros', null, "/temp1barbaros"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Doom patrols', null, "/temp1doompatrol"),
		],
		[
			$tlg->buildInlineKeyboardButton ('After life', null, "/temp1afterlife"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Gen v', null, "/temp1genv"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Invasão', null, "/temp1invasao"),
		],
		[
			$tlg->buildInlineKeyboardButton ('One Piece', null, "/temp1onepiece"),
		],
		[
			$tlg->buildInlineKeyboardButton ('As Flores Perdidas de Alice Hart', null, "/temp1asfloresperdidasdealicehart"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Station Eleven', null, "/temp1stationeleven"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Mayor of Kingstown', null, "/temp1mayorofkingstown"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Treta / beef', null, "/temp1tretabeef"),
		],
		[
			$tlg->buildInlineKeyBoardButton ('↩️ VOLTAR ', null, "/start"),$tlg->buildInlineKeyBoardButton ('▶️ PRÓXIMO ', null, "/pagina2serie"),
		],
	], true, true)
	];
// Crie o array $dados_mensagem com a foto
$dados_mensagem = [
    'chat_id' => $tlg->ChatID(),
    'photo' => $foto_url,
    'caption' => $mensagem,
    'parse_mode' => 'html',
    'disable_web_page_preview' => true,
    'reply_markup' => $tlg->buildInlineKeyboard([
		[
			$tlg->buildInlineKeyboardButton ('Bárbaros', null, "/aquelacancaodenatal"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Doom patrols', null, "/anoitedasvampiras"),
		],
		[
			$tlg->buildInlineKeyboardButton ('After life', null, "/asutilartedeligarofodase"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Gem v', null, "/alista"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Invasão', null, "/amizadeferias2"),
		],
		[
			$tlg->buildInlineKeyboardButton ('One Piece', null, "/amoraoquadradoparasempre"),
		],
		[
			$tlg->buildInlineKeyboardButton ('As Flores Perdidas de Alice Hart', null, "/adamasiliencio"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Station Eleven', null, "/amorverdairos"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Mayor of Kingstown', null, "/afilhadanoiva"),
		],
		[
			$tlg->buildInlineKeyboardButton ('Treta / beef', null, "/asteroidcity"),
		],
		[
			$tlg->buildInlineKeyBoardButton ('↩️ VOLTAR ', null, "/start"),$tlg->buildInlineKeyBoardButton ('▶️ PRÓXIMO ', null, "/pagina2serie"),
		],
	], true, true)
	];

// Verifique se a ação é acionada por um callback
if ($tlg->Callback_ID() !== null) {
    // Exclua a mensagem anterior
    $tlg->deleteMessage([
        'chat_id' => $tlg->ChatID(),
        'message_id' => $tlg->MessageID(),
    ]);
    
    // Envie a nova mensagem com a imagem atualizada e os botões
    $tlg->sendPhoto($dados_mensagem2);
} else {
    // Envie a mensagem normal se não for um callback
    $tlg->sendPhoto($dados_mensagem);

}
?>
