<?php
$bd_tlg->setPais ($tlg->UserID (), $id_pais);
$id_pais = (PAISES [$complemento]) ? $complemento : 73;
$pais = PAISES [$id_pais];
$saldo = (string)number_format ($user ['saldo'], 2);

$tlg->answerCallbackQuery ([
	'callback_query_id' => $tlg->Callback_ID (),
	'text' => 'Gerando link de pagamento...'
]);

$valor = number_format ($complemento, 2);
$hash = $tlg->UserID ().mt_rand(111111, 999999);

$mp = new MercadoPago (ACCESS_TOKEN_MERCADO_PAGO);
$pagamento = $mp->setPreferencia ([
	"items" => [
		[
			"picture_url" => "https://i.ibb.co/jvGWdZK/photo-2023-07-24-05-47-25.jpg",
			"title" => "Assinatura @KingPlayMovieBOT",
            "description" => "Saldo enviado Para sua conta, voce acaba de fazer uma venda!!!",
            "quantity" => 1,
            "currency_id" => "BRL",
            "unit_price" => (float)$valor
		]
	],
	"external_reference" => $hash,
	"expires" => true,
	"expiration_date_to" => date ('c', strtotime('+1 day'))
]);

if (!isset ($pagamento ['external_reference'])){

	$tlg->editMessageText ([
		'chat_id' => $tlg->ChatID (),
		'text' => "<em>⚠️ Erro ao gerar o seu link de pagamento, por favor tente novamente!\n ou tente o pagamento manual digitando /pixmanual</em>",
		'parse_mode' => 'html',
		'message_id' => $tlg->MessageID (),
		'reply_markup' => $tlg->buildInlineKeyboard ([
			[
				$tlg->buildInlineKeyBoardButton ("Tentar Novamente", null, "/comprar {$valor}")
			]
		])
	]);

}else {
	$atraso = 2;
	$tlg->sendPhoto([
		'chat_id' => $tlg->ChatID(),
		'photo' => 'https://i.ibb.co/MRKnrJg/Captura-de-tela-2023-10-10-183110.png',
		'caption' => "🔐 Assinaturas Premium com KingMovie 🎬\n\nClique no link de pagamento gerado.\nSiga as instruções para concluir o processo de pagamento seguro.\nApós a confirmação, sua assinatura Premium será ativada automaticamente.\n\nAproveite uma experiência de cinema superior com as assinaturas Premium do KingMovie! 🎥🍿🔒",
		'parse_mode' => 'html',
		'reply_markup' => $tlg->buildInlineKeyboard([
			[
				$tlg->buildInlineKeyBoardButton("Pagar R\${$valor}", $pagamento['init_point'])
			],
			[
				$tlg->buildInlineKeyBoardButton("↩️ Voltar", null, "/start")
			]
		])
	]);

}

// Verifique se a ação é acionada por um callback
if ($tlg->Callback_ID() !== null) {
    // Exclua a mensagem anterior
    $tlg->deleteMessage([
        'chat_id' => $tlg->ChatID(),
        'message_id' => $tlg->MessageID(),
    ]);
    
    // Envie a nova mensagem com a imagem atualizada e os botões
    $tlg->sendPhoto($dados_mensagem2);
} else {
    // Envie a mensagem normal se não for um callback
    $tlg->sendPhoto($dados_mensagem);

}
?>



