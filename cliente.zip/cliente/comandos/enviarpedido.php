
<?php
 if ($user['saldo'] == 49.90) {
    // Se o saldo for igual a 49.90, encaminhe a mensagem normalmente
	if (!$complemento){
		$tlg->sendMessage ([
			'chat_id' => $tlg->ChatID (),
			'text' => "Digite o comando /enviar TEXTO\nExemplo: <b>/enviar Bom dia!!!</b> ",
			'parse_mode' => 'html'
		]);
	}else {
			$msg = @$tlg->sendMessage ([
				'chat_id' => '-1002028853824',
				'text' => "Pedido Filme / Serie: <b>$complemento</b>\n\n🪪  ID usuário: {$tlg->ChatID()}\n👤 Nome: {$tlg->FirstName ()}\n👤 Username: @{$tlg->Username()}",
				'parse_mode' => 'html'
			]);
			if ($msg ['ok']){
				$tlg->sendMessage([
					'chat_id' => $tlg->ChatID (),
					'text' => "Pedido Filme Enviado com sucesso!",
				]);
			}
	}
} else {
    // Se o saldo não for igual a 0 nem 49.90, notificamos o usuário
    $tlg->sendMessage([
        'chat_id' => $tlg->ChatID(),
        'text' => "Os pedidos estão disponíveis apenas para usuários assinantes.😢",
        'parse_mode' => 'html',
        'message_id' => $tlg->MessageID (),
        'disable_web_page_preview' => 'true',
        'reply_markup' => $tlg->buildInlineKeyboard ([
            [
                $tlg->buildInlineKeyBoardButton ('Recarregar', null, '/recarregar'),
            ],
            [
                $tlg->buildInlineKeyBoardButton ('↩️ Voltar', null, "/start")
            ],
        ])
    ]);
}
