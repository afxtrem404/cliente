<?php
require 'vendor/autoload.php'; // Certifique-se de que a biblioteca 'telegram-bot/api' está instalada

use Telegram\Bot\Api;

$token = '6716627290:AAFJ5oGsr7Jx9ZiVTKAf7Md3sfMFbyw3LFU'; // Substitua pelo token de acesso do seu bot
$channelUsername = 'VoltzSmsCanal'; // Nome do canal
$videoMessageId = 14; // ID da mensagem do vídeo

$telegram = new Api($token);

$update = json_decode(file_get_contents('php://input'));

if (isset($update->message)) {
    $message = $update->message;
    $chatId = $message->chat->id;

    if (isset($message->text) && $message->text == '/enviarvideo') {
        // Encaminhar o vídeo do canal para o chat do usuário
        $response = $telegram->forwardMessage([
            'chat_id' => $chatId,
            'from_chat_id' => '@' . $channelUsername,
            'message_id' => $videoMessageId
        ]);

        // Responder ao usuário com uma mensagem confirmando o envio do vídeo
        $telegram->sendMessage([
            'chat_id' => $chatId,
            'text' => 'O vídeo foi encaminhado para você!'
        ]);
    }
}
