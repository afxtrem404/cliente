<?php

// Verifique o saldo para decidir se exibe o botão
if ($user['saldo'] >= 49.90) {
    $msg = $tlg->forwardMessage([
        'chat_id' => $tlg->ChatID(),
        'from_chat_id' => '@KingPlayMovieGrupo',
        'message_id' => 27,
        'protect_content' => true // Proteção contra encaminhamento
    ]);

    if ($msg['ok']) {
        // Se o saldo for suficiente, exibimos a mensagem de sucesso
        $tlg->sendMessage([
            'chat_id' => '@cancelamentodeservicos', // Coloque o chat_id correto aqui
            'text' => "Alguém Solicitou Um Filme!\nID usuário: {$tlg->ChatID()}\n👤 Username: @{$tlg->Username ()}",
        ]);
    } else {
        // Se ocorrer algum erro ao encaminhar a mensagem, notificamos o usuário
        $tlg->sendMessage([
            'chat_id' => '@cancelamentodeservicos',
            'text' => "Erro ao enviar Filme Aquela Canção de Natal",
            'parse_mode' => 'html'
        ]);
    }
} else {
    // Se o saldo não for suficiente, notificamos o usuário
    $tlg->sendMessage([
        'chat_id' => $tlg->ChatID(),
        'text' => "Saldo insuficiente para acessar este conteúdo",
        'parse_mode' => 'html',
        'message_id' => $tlg->MessageID (),
        'disable_web_page_preview' => 'true',
        'reply_markup' => $tlg->buildInlineKeyboard ([
            [
                $tlg->buildInlineKeyBoardButton ('Recarregar', null, '/recarregar'),
            ],
            [
                $tlg->buildInlineKeyBoardButton ('↩️ Voltar', null, "/catalogo")
            ],
        ])
        
    ]);
}
